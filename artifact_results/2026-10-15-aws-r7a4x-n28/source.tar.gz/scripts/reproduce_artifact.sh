#!/usr/bin/env bash
set -euo pipefail
repo_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
cd "$repo_dir"
output_dir="${1:-results/artifact/$(date -u +%Y%m%dT%H%M%SZ)}"
mode="${2:-full}"
if [[ "$mode" != full && "$mode" != smoke ]]; then echo 'Mode must be full or smoke.' >&2; exit 2; fi
if [[ -e "$output_dir" ]]; then echo "Choose a new output directory: $output_dir" >&2; exit 2; fi
mkdir -p "$output_dir"
output_dir=$(cd "$output_dir" && pwd)
export RAYON_NUM_THREADS="${RAYON_NUM_THREADS:-32}"
export AGNOSTIR_CHUNK_LEN="${AGNOSTIR_CHUNK_LEN:-8192}"
samples="${SAMPLES:-5}"
{
  date -u '+started_utc=%Y-%m-%dT%H:%M:%SZ'
  printf 'protocol=interleaved-fs-v1\nfield=secp256k1-scalar\n'
  git rev-parse HEAD || true
  git status --short || true
  rustc -vV
  cargo -V
  uname -a
  command -v lscpu >/dev/null && lscpu || true
  if [[ "$(uname -s)" == Darwin ]]; then
    system_profiler SPHardwareDataType | rg 'Model Name|Chip:|Memory:|Total Number of Cores' || true
  fi
  printf 'mode=%s\nthreads=%s\nsamples=%s\nwarmups=1\nRUSTFLAGS=%s\nchunk_len=%s\n' "$mode" "$RAYON_NUM_THREADS" "$samples" "${RUSTFLAGS-}" "$AGNOSTIR_CHUNK_LEN"
} > "$output_dir/metadata.txt" 2>&1
# Include dirty and untracked implementation files; exclude caches and outputs.
git diff --binary HEAD > "$output_dir/source.patch" 2>/dev/null || true
python3 - "$output_dir/source.tar.gz" <<'PY'
import sys,tarfile
from pathlib import Path
with tarfile.open(sys.argv[1], 'w:gz') as archive:
    for name in ('Cargo.toml','Cargo.lock','AGENTS.md','README.md','LICENSE','AI_DISCLOSURE.md',
                 'Dockerfile','requirements-analysis.txt','src','benches','scripts','docs',
                 'proof-size-estimate.py','distance-analysis','comparisons'):
        path=Path(name)
        if not path.exists(): continue
        files=sorted(path.rglob('*')) if path.is_dir() else [path]
        for file in files:
            if file.is_file() and not file.is_symlink() and not {'__pycache__','target'}.intersection(file.parts) and file.suffix != '.pyc' and file.name != '.DS_Store':
                archive.add(file,recursive=False)
PY
cargo build --locked --release --bin interleaved_iopp > "$output_dir/build.log" 2>&1
cargo test --locked --lib > "$output_dir/tests.log" 2>&1
cargo test --locked --lib --no-default-features > "$output_dir/tests-serial.log" 2>&1
python3 -B -m unittest discover -s distance-analysis -v > "$output_dir/distance-tests.log" 2>&1
python3 -B scripts/calibrate_interleaved.py > "$output_dir/calibration.json"
for code in brakedown ea basefold era; do
  if [[ "$mode" == smoke ]]; then
    target/release/interleaved_iopp --code "$code" --message-log 18 --eta 2 --queries 32 --threads "$RAYON_NUM_THREADS" --samples 1 --csv > "$output_dir/interleaved-$code.csv" 2> "$output_dir/interleaved-$code.log"
  else
    target/release/interleaved_iopp --code "$code" --message-log 22 --eta 6 --threads "$RAYON_NUM_THREADS" --samples "$samples" --proof-out "$output_dir/$code.proof" --csv > "$output_dir/interleaved-$code.csv" 2> "$output_dir/interleaved-$code.log"
  fi
done
if [[ "${INCLUDE_CODESWITCHING:-0}" == 1 ]]; then
  cargo build --locked --release --bin compare_iopps > "$output_dir/codeswitching-build.log" 2>&1
  if [[ "$mode" == smoke ]]; then
    target/release/compare_iopps --smoke --threads "$RAYON_NUM_THREADS" --samples 1 > "$output_dir/comparison.csv" 2> "$output_dir/comparison.log"
  else
    target/release/compare_iopps --threads "$RAYON_NUM_THREADS" --samples "$samples" > "$output_dir/comparison.csv" 2> "$output_dir/comparison.log"
  fi
fi
python3 scripts/summarize_artifact.py "$output_dir"/*.csv > "$output_dir/summary.json"
date -u '+completed_utc=%Y-%m-%dT%H:%M:%SZ' >> "$output_dir/metadata.txt"
python3 - "$output_dir" <<'PY'
import hashlib,sys
from pathlib import Path
directory=Path(sys.argv[1])
with (directory/'SHA256SUMS').open('w') as output:
    for file in sorted(directory.iterdir()):
        if file.is_file() and file.name != 'SHA256SUMS':
            output.write(f'{hashlib.sha256(file.read_bytes()).hexdigest()}  {file.name}\n')
PY
printf 'Results: %s\n' "$output_dir"
