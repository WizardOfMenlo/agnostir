#!/usr/bin/env bash
# Alternate original/checkpointed ERA profiles to balance execution order.
set -euo pipefail
cd "$(dirname "$0")/.."
out="${1:?usage: THREADS=8 BLOCKS=4 SAMPLES=2 WARMUPS=1 bash scripts/profile_gkr_comparison.sh OUTPUT_DIR}"
if [[ -e "$out" ]]; then
    echo "Refusing to overwrite $out" >&2
    exit 1
fi
threads="${THREADS:-8}"
blocks="${BLOCKS:-4}"
samples="${SAMPLES:-2}"
warmups="${WARMUPS:-1}"
for value in "$threads" "$blocks" "$samples"; do
    [[ "$value" =~ ^[1-9][0-9]*$ ]] || { echo 'Expected positive integer' >&2; exit 1; }
done
[[ "$warmups" =~ ^[0-9]+$ ]] || { echo 'Expected nonnegative warmups' >&2; exit 1; }
mkdir -p "$out"
{
    date -u
    uname -sm
    rustc -Vv
    cargo -V
    git rev-parse HEAD
    git status --short
    printf 'THREADS=%s\nBLOCKS=%s\nSAMPLES=%s\nWARMUPS=%s\nRUSTFLAGS=%s\n' \
        "$threads" "$blocks" "$samples" "$warmups" "${RUSTFLAGS:-}"
    if [[ "$(uname -s)" == Darwin ]]; then
        system_profiler SPHardwareDataType | python3 -c '
import sys
keys = ("Model Name:", "Model Identifier:", "Chip:", "Total Number of Cores:", "Memory:")
print("".join(line for line in sys.stdin if line.strip().startswith(keys)), end="")'
        sw_vers
    else
        lscpu
        cat /proc/meminfo
    fi
} > "$out/environment.txt"
tar -czf "$out/source.tar.gz" Cargo.toml Cargo.lock AGENTS.md README.md .gitignore \
    Dockerfile AI_DISCLOSURE.md requirements-analysis.txt src benches scripts distance-analysis docs
cargo build --release --locked --bin compare_iopps > "$out/build.log" 2>&1
for ((block=0; block<blocks; block++)); do
    modes=(original checkpoints)
    if ((block % 2 == 1)); then modes=(checkpoints original); fi
    for mode in "${modes[@]}"; do
        args=(--protocol era --threads "$threads" --samples "$samples" --warmups "$warmups")
        if [[ "$mode" == checkpoints ]]; then args+=(--gkr-checkpoints 3,7,11,15); fi
        if ((block == 0)); then args+=(--proof-dir "$out/proofs"); fi
        printf 'block=%s mode=%s\n' "$block" "$mode" | tee -a "$out/order.txt" >&2
        target/release/compare_iopps "${args[@]}" \
            --profile-out "$out/stages-t$threads-b$block-$mode.csv" \
            > "$out/timings-t$threads-b$block-$mode.csv" \
            2> "$out/run-t$threads-b$block-$mode.log"
    done
done
python3 scripts/summarize_iopp_profile.py "$out" > "$out/summary.json"
python3 scripts/summarize_gkr_comparison.py "$out" > "$out/comparison.json"
python3 - "$out" <<'PY'
import hashlib
import sys
from pathlib import Path
root = Path(sys.argv[1])
with (root / 'SHA256SUMS').open('w') as out:
    for path in sorted(root.rglob('*')):
        if path.is_file() and path.name != 'SHA256SUMS':
            out.write(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(root)}\n')
PY
echo "Verified paired GKR profiles saved in $out" >&2
