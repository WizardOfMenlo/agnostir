#!/usr/bin/env bash
# Compare the original and checkpointed ERA prover with identical query counts.
set -euo pipefail
cd "$(dirname "$0")/.."
out="${1:?usage: THREADS=8 SAMPLES=3 WARMUPS=1 bash scripts/reproduce_gkr_checkpoints.sh OUTPUT_DIR}"
if [[ -e "$out" ]]; then
    echo "Refusing to overwrite $out" >&2
    exit 1
fi
mkdir -p "$out"
threads="${THREADS:-8}"
samples="${SAMPLES:-3}"
warmups="${WARMUPS:-1}"
{
    date -u
    uname -sm
    rustc -Vv
    cargo -V
    git rev-parse HEAD
    git status --short
    printf 'THREADS=%s\nSAMPLES=%s\nWARMUPS=%s\nRUSTFLAGS=%s\n' "$threads" "$samples" "$warmups" "${RUSTFLAGS:-}"
    if [[ "$(uname -s)" == Darwin ]]; then
        system_profiler SPHardwareDataType | python3 -c '
import sys
keys = ("Model Name:", "Model Identifier:", "Chip:", "Total Number of Cores:", "Memory:")
print("".join(line for line in sys.stdin if line.strip().startswith(keys)), end="")'
        sw_vers
    else
        lscpu
        cat /proc/meminfo
    fi
} > "$out/environment.txt"
tar -czf "$out/source.tar.gz" Cargo.toml Cargo.lock AGENTS.md README.md .gitignore \
    Dockerfile AI_DISCLOSURE.md requirements-analysis.txt src benches scripts distance-analysis docs
python3 -B scripts/calibrate_custom.py > "$out/calibration.json"
cargo build --release --locked --bin compare_iopps > "$out/build.log" 2>&1
for mode in original checkpoints; do
    extra=(--protocol era)
    if [[ "$mode" == checkpoints ]]; then
        extra=(--protocol era --gkr-checkpoints 3,7,11,15)
    fi
    target/release/compare_iopps --threads "$threads" \
        --samples "$samples" --warmups "$warmups" "${extra[@]}" \
        --profile-out "$out/stages-t$threads-$mode.csv" --proof-dir "$out/proofs" \
        > "$out/timings-t$threads-$mode.csv" 2> "$out/run-t$threads-$mode.log"
    target/release/compare_iopps --threads "$threads" \
        --samples "$samples" --warmups "$warmups" "${extra[@]}" \
        > "$out/control-t$threads-$mode.csv" 2> "$out/control-t$threads-$mode.log"
done
python3 scripts/summarize_iopp_profile.py "$out" > "$out/summary.json"
python3 - "$out" <<'PY'
import hashlib
import sys
from pathlib import Path
root = Path(sys.argv[1])
with (root / 'SHA256SUMS').open('w') as out:
    for path in sorted(root.rglob('*')):
        if path.is_file() and path.name != 'SHA256SUMS':
            out.write(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(root)}\n')
PY
echo "Verified original/checkpointed ERA profiles saved in $out" >&2
