#!/usr/bin/env bash
# Fresh six-protocol comparison on r7a.4xlarge; no retained pilot rows.
set -euo pipefail
cd "$(dirname "$0")/.."
output=${1:-results/aws-r7a4x-n28}
if [[ "$output" == --dry-run ]]; then
    output=results/aws-r7a4x-n28
    shift
    set -- --dry-run "$@"
else
    if [[ $# -gt 0 ]]; then shift; fi
fi
python3 -B scripts/run_large_iopp_plan.py \
    artifact_results/2026-10-15-aws-r7a4x-n28/plan.json "$output" \
    --logs 28 --threads 16 --samples 1 --warmups 1 --memory-budget-gib 112 \
    --instance-type r7a.4xlarge "$@"
