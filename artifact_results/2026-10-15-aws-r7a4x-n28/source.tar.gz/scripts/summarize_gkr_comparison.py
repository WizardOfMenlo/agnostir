#!/usr/bin/env python3
"""Compare GKR profiles, matching checkpoint batches to their original depths."""
import argparse
import csv
import json
import statistics
from collections import defaultdict
from pathlib import Path

from summarize_iopp_profile import summarize


GKR = "prove/permutation_checks/logup_gkr"
CLAIMS = "prove/claim_reduction"
DEPTHS = [[0, 3, 7, 11, 15], [1, 4, 8, 12, 16],
          [2, 5, 9, 13, 17], [6, 10, 14, 18]]
ORIGINAL = "era-corrected"
CHECKPOINTS = "era-checkpoint-3-7-11-15"


def stats(values):
    return dict(mean=statistics.mean(values), median=statistics.median(values),
                min=min(values), max=max(values))


def measure(rows):
    elapsed = defaultdict(float)
    counts = defaultdict(int)
    wire = defaultdict(int)
    for row in rows:
        path = row["path"]
        elapsed[path] += float(row["inclusive_ms"])
        counts[path] += 1
        wire[path] += int(row["inclusive_bytes"])
    checkpointed = rows[0]["protocol"] == CHECKPOINTS
    batch_metrics = []
    if checkpointed:
        for i, depths in enumerate(DEPTHS):
            prefix = f"{GKR}/batch_{i}_d{max(depths)}"
            sc = prefix + "/sumcheck"
            assert counts[sc] == 1
            assert counts[sc + "/polynomial_evaluation"] == max(depths)
            assert counts[sc + "/table_folding"] == max(depths)
            batch_metrics.append(dict(
                tables_ms=elapsed[prefix + "/layer_tables"],
                sumcheck_ms=elapsed[sc],
                polynomial_ms=elapsed[sc + "/polynomial_evaluation"],
                folding_ms=elapsed[sc + "/table_folding"],
            ))
    else:
        # Profile::start appends in preorder; the original GKR loop visits
        # depth 0..18. Check child-round counts before assigning depth labels.
        tables = [float(r["inclusive_ms"]) for r in rows
                  if r["path"] == GKR + "/layer_tables"]
        layers = []
        for i, row in enumerate(rows):
            if row["path"] != GKR + "/layer_sumchecks":
                continue
            children = []
            for child in rows[i + 1:]:
                if not child["path"].startswith(row["path"] + "/"):
                    break
                children.append(child)
            parts = {}
            for part in ("polynomial_evaluation", "table_folding"):
                values = [float(c["inclusive_ms"]) for c in children
                          if c["path"] == row["path"] + "/" + part]
                assert len(values) == len(layers), "unexpected original GKR order"
                parts[part] = sum(values)
            layers.append(dict(
                tables_ms=tables[len(layers)],
                sumcheck_ms=float(row["inclusive_ms"]),
                polynomial_ms=parts["polynomial_evaluation"],
                folding_ms=parts["table_folding"],
            ))
        assert len(layers) == len(tables) == 19
        for depths in DEPTHS:
            batch_metrics.append({k: sum(layers[d][k] for d in depths) for k in layers[0]})
    total = {k: sum(b[k] for b in batch_metrics) for k in batch_metrics[0]}
    total.update(
        fraction_trees_ms=elapsed[GKR + "/fraction_trees"],
        checkpoint_commitment_ms=elapsed[GKR + "/checkpoint_commitment"],
        checkpoint_encode_ms=elapsed[GKR + "/checkpoint_commitment/encode"],
        checkpoint_merkle_ms=elapsed[GKR + "/checkpoint_commitment/merkle"],
        checkpoint_pack_ms=elapsed[GKR + "/checkpoint_commitment/pack"],
        checkpoint_oods_ms=elapsed[GKR + "/checkpoint_oods"],
        boundary_claims_ms=elapsed[GKR + "/boundary_claims"],
        checkpoint_authentication_ms=elapsed[GKR + "/checkpoint_authentication_claims"],
        gkr_ms=elapsed[GKR],
        claim_reduction_ms=elapsed[CLAIMS],
        claim_build_tables_ms=elapsed[CLAIMS + "/build_tables"],
        claim_sumcheck_ms=elapsed[CLAIMS + "/batched_sumcheck"],
        claim_endpoint_ms=elapsed[CLAIMS + "/endpoint_checks"],
        claim_terminal_basefold_ms=elapsed[CLAIMS + "/terminal_basefold"],
        prove_ms=elapsed["prove"],
    )
    total["sumcheck_other_ms"] = total["sumcheck_ms"] - total["polynomial_ms"] - total["folding_ms"]
    total["gkr_other_ms"] = total["gkr_ms"] - sum(total[k] for k in (
        "fraction_trees_ms", "tables_ms", "sumcheck_ms", "checkpoint_commitment_ms",
        "checkpoint_oods_ms", "boundary_claims_ms", "checkpoint_authentication_ms"))
    total["outside_gkr_and_claim_reduction_ms"] = (
        total["prove_ms"] - total["gkr_ms"] - total["claim_reduction_ms"])
    assert total["gkr_other_ms"] > -0.01
    rounds = sum(max(ds) for ds in DEPTHS) if checkpointed else sum(range(19))
    sumcheck_bytes = sum(wire[path] for path in wire
                        if path.startswith(GKR + "/") and path.endswith("/polynomial_evaluation"))
    assert sumcheck_bytes == 128 * rounds
    return total, batch_metrics, dict(rounds=rounds, sumcheck_bytes=sumcheck_bytes,
                                      gkr_bytes=wire[GKR], proof_bytes=wire["prove"])


def compare(directory):
    # Independently validate proof acceptance, complete time/byte accounting,
    # and deterministic proof identity across every recorded run.
    validated = summarize(directory)
    assert len({r["threads"] for r in validated["results"]}) == 1
    runs = defaultdict(list)
    batches = defaultdict(list)
    identities = {}
    for path in sorted(directory.glob("stages-t*.csv")):
        per_run = defaultdict(list)
        with path.open() as file:
            for row in csv.DictReader(file):
                if row["protocol"] in (ORIGINAL, CHECKPOINTS):
                    per_run[row["protocol"], row["sample"]].append(row)
        for (protocol, _), rows in per_run.items():
            metrics, batch, identity = measure(rows)
            assert identities.setdefault(protocol, identity) == identity
            runs[protocol].append(metrics)
            batches[protocol].append(batch)
    assert set(runs) == {ORIGINAL, CHECKPOINTS}
    result = {}
    for protocol, measurements in runs.items():
        result[protocol] = dict(
            samples=len(measurements), **identities[protocol],
            metrics={k: stats([m[k] for m in measurements]) for k in measurements[0]},
            batches=[dict(depths=depths, metrics={
                k: stats([b[i][k] for b in batches[protocol]]) for k in batches[protocol][0][i]
            }) for i, depths in enumerate(DEPTHS)],
        )
    delta = {k: result[CHECKPOINTS]["metrics"][k]["mean"] - result[ORIGINAL]["metrics"][k]["mean"]
             for k in result[ORIGINAL]["metrics"]}
    return dict(threads=validated["results"][0]["threads"], results=result,
                checkpoint_minus_original_mean_ms=delta,
                folded_positions_per_table=sum((1 << d) - 1 for d in range(19)),
                deepest_four_position_fraction=sum((1 << d) - 1 for d in range(15, 19))
                / sum((1 << d) - 1 for d in range(19)))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    print(json.dumps(compare(args.directory), indent=2))
