#!/usr/bin/env bash
# Full-size, conditional-parameter profiling. No new distance/security claims.
set -euo pipefail
cd "$(dirname "$0")/.."
out="${1:?usage: THREAD_COUNTS='8 1' SAMPLES=3 WARMUPS=1 bash scripts/reproduce_iopp_profile.sh OUTPUT_DIR}"
if [[ -e "$out" ]]; then
    echo "Refusing to overwrite $out" >&2
    exit 1
fi
mkdir -p "$out"
thread_counts="${THREAD_COUNTS:-8 1}"
samples="${SAMPLES:-3}"
warmups="${WARMUPS:-1}"
{
    date -u
    uname -sm
    rustc -Vv
    cargo -V
    git rev-parse HEAD
    git status --short
    printf 'THREAD_COUNTS=%s\nSAMPLES=%s\nWARMUPS=%s\nRUSTFLAGS=%s\n' "$thread_counts" "$samples" "$warmups" "${RUSTFLAGS:-}"
    if [[ "$(uname -s)" == Darwin ]]; then
        if ! sysctl hw.model machdep.cpu.brand_string hw.ncpu hw.memsize 2>&1; then
            # Sandboxed macOS can restrict sysctl; retain only non-identifying
            # hardware fields from the fallback, excluding serial numbers/UUIDs.
            system_profiler SPHardwareDataType | python3 -c '
import sys
keys = ("Model Name:", "Model Identifier:", "Chip:", "Total Number of Cores:", "Memory:")
print("".join(line for line in sys.stdin if line.strip().startswith(keys)), end="")'
        fi
        sw_vers
    else
        lscpu
        cat /proc/meminfo
    fi
} > "$out/environment.txt"
tar -czf "$out/source.tar.gz" Cargo.toml Cargo.lock AGENTS.md README.md .gitignore \
    Dockerfile AI_DISCLOSURE.md requirements-analysis.txt src benches scripts distance-analysis docs
python3 -B scripts/calibrate_custom.py > "$out/calibration.json"
cargo build --release --locked --bin compare_iopps > "$out/build.log" 2>&1
first=""
for threads in $thread_counts; do
    proof_args=()
    if [[ -z "$first" ]]; then
        first="$threads"
        proof_args=(--proof-dir "$out/proofs")
    fi
    target/release/compare_iopps --threads "$threads" --samples "$samples" --warmups "$warmups" \
        --profile-out "$out/stages-t$threads.csv" "${proof_args[@]}" \
        > "$out/timings-t$threads.csv" 2> "$out/run-t$threads.log"
done
# A control run confirms that instrumentation leaves proof bytes unchanged.
target/release/compare_iopps --threads "$first" --samples "$samples" --warmups "$warmups" \
    > "$out/control-t$first.csv" 2> "$out/control-t$first.log"
python3 scripts/summarize_iopp_profile.py "$out" > "$out/summary.json"
python3 - "$out" <<'PY'
import hashlib
import sys
from pathlib import Path
root = Path(sys.argv[1])
with (root / 'SHA256SUMS').open('w') as out:
    for path in sorted(root.rglob('*')):
        if path.is_file() and path.name != 'SHA256SUMS':
            out.write(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(root)}\n')
PY
echo "Verified profiles, raw proofs and summary saved in $out" >&2
