#!/usr/bin/env bash
# Keep the retained ERA/BaseFold measurements; run only the four missing cases.
set -euo pipefail
cd "$(dirname "$0")/.."
output=results/aws-n28-remaining
if (($#)) && [[ "$1" != --dry-run ]]; then output=$1; shift; fi
if (( $# > 1 )) || { (( $# == 1 )) && [[ "$1" != --dry-run ]]; }; then
    printf 'Usage: %s [fresh-output-directory] [--dry-run]\n' "$0" >&2
    exit 2
fi
exec python3 -B scripts/run_large_iopp_plan.py \
    artifact_results/2026-10-15-aws-size-plan/plan.json "$output" \
    --logs 28 --threads 32 --samples 1 --warmups 1 \
    --protocols interleaved-brakedown interleaved-ea era-codeswitch basefold-local \
    --memory-budget-gib 224 --instance-type r7a.8xlarge "$@"
