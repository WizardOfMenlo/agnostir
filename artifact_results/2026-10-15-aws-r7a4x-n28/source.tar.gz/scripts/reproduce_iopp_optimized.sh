#!/usr/bin/env bash
# Benchmark optimized uncheckpointed ERA and local BaseFold.
# Set INCLUDE_CHECKPOINTS=1 to also reproduce the historical checkpoint comparison.
# Compare actual proof bytes to a pre-optimization reference directory.
set -euo pipefail
cd "$(dirname "$0")/.."
out="${1:?usage: THREADS=8 SAMPLES=3 WARMUPS=1 bash scripts/reproduce_iopp_optimized.sh OUTPUT_DIR REFERENCE_PROOF_DIR}"
reference="${2:?supply the pre-optimization proof directory}"
include_checkpoints="${INCLUDE_CHECKPOINTS:-0}"
if [[ "$include_checkpoints" != 0 && "$include_checkpoints" != 1 ]]; then
    echo "INCLUDE_CHECKPOINTS must be 0 or 1" >&2
    exit 1
fi
if [[ -e "$out" ]]; then
    echo "Refusing to overwrite $out" >&2
    exit 1
fi
mkdir -p "$out"
threads="${THREADS:-8}"
samples="${SAMPLES:-3}"
warmups="${WARMUPS:-1}"
{
    date -u
    uname -sm
    rustc -Vv
    cargo -V
    git rev-parse HEAD
    git status --short
    printf 'THREADS=%s\nSAMPLES=%s\nWARMUPS=%s\nRUSTFLAGS=%s\n' "$threads" "$samples" "$warmups" "${RUSTFLAGS:-}"
    printf 'INCLUDE_CHECKPOINTS=%s\n' "$include_checkpoints"
    if [[ "$(uname -s)" == Darwin ]]; then
        system_profiler SPHardwareDataType | python3 -c '
import sys
keys = ("Model Name:", "Model Identifier:", "Chip:", "Total Number of Cores:", "Memory:")
print("".join(line for line in sys.stdin if line.strip().startswith(keys)), end="")'
        sw_vers
    else
        lscpu
        cat /proc/meminfo
    fi
} > "$out/environment.txt"
tar -czf "$out/source.tar.gz" Cargo.toml Cargo.lock AGENTS.md README.md .gitignore \
    Dockerfile AI_DISCLOSURE.md requirements-analysis.txt src benches scripts distance-analysis docs
python3 -B scripts/calibrate_custom.py > "$out/calibration.json"
cargo build --release --locked --bin compare_iopps > "$out/build.log" 2>&1
modes=(original)
if [[ "$include_checkpoints" == 1 ]]; then modes=(checkpoints original); fi
for mode in "${modes[@]}"; do
    extra=(--protocol both)
    if [[ "$mode" == checkpoints ]]; then
        extra=(--protocol era --gkr-checkpoints 3,7,11,15)
    fi
    target/release/compare_iopps --threads "$threads" \
        --samples "$samples" --warmups "$warmups" "${extra[@]}" \
        --profile-out "$out/stages-t$threads-$mode.csv" --proof-dir "$out/proofs" \
        > "$out/timings-t$threads-$mode.csv" 2> "$out/run-t$threads-$mode.log"
    target/release/compare_iopps --threads "$threads" \
        --samples "$samples" --warmups "$warmups" "${extra[@]}" \
        > "$out/control-t$threads-$mode.csv" 2> "$out/control-t$threads-$mode.log"
done
python3 scripts/summarize_iopp_profile.py "$out" > "$out/summary.json"
python3 - "$out" "$reference" "$include_checkpoints" <<'PY'
import hashlib
import json
import sys
from pathlib import Path
root = Path(sys.argv[1])
reference = Path(sys.argv[2])
expected = {'era-corrected.proof', 'basefold-local.proof'}
if sys.argv[3] == '1':
    expected.add('era-checkpoint-3-7-11-15.proof')
identities = []
for proof in sorted((root / 'proofs').glob('*.proof')):
    old = reference / proof.name
    data = proof.read_bytes()
    assert data == old.read_bytes(), f'Proof bytes differ: {proof.name}'
    identities.append(dict(proof=proof.name, reference=str(old), bytes=len(data),
                           sha256=hashlib.sha256(data).hexdigest(), identical=True))
assert {entry['proof'] for entry in identities} == expected
(root / 'proof-identity.json').write_text(json.dumps(identities, indent=2) + '\n')
with (root / 'SHA256SUMS').open('w') as out:
    for path in sorted(root.rglob('*')):
        if path.is_file() and path.name != 'SHA256SUMS':
            out.write(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(root)}\n')
PY
echo "Verified byte-identical ERA/BaseFold proofs and profiles saved in $out" >&2
