#!/usr/bin/env python3
"""Compare before/after unprofiled runs and check actual serialized proof bytes."""
import argparse
import csv
import json
import statistics
from pathlib import Path


def summarize(root):
    results = {}
    for phase in ("before", "after"):
        groups = {}
        for path in sorted((root / phase).glob("control-t*-*.csv")):
            with path.open() as file:
                for row in csv.DictReader(file):
                    assert row["accepted"] == "true", row
                    groups.setdefault((row["protocol"], row["threads"]), []).append(row)
        for (protocol, threads), rows in groups.items():
            result = results.setdefault((protocol, threads), {})
            metrics = {}
            for key in ("commit_ms", "prove_ms", "verify_ms", "total_prover_ms"):
                values = [float(r["commit_ms"]) + float(r["prove_ms"])
                          if key == "total_prover_ms" else float(r[key]) for r in rows]
                metrics[key] = dict(median=statistics.median(values),
                                    mean=statistics.mean(values), min=min(values), max=max(values))
            proof = (root / phase / "proofs" / f"{protocol}.proof").read_bytes()
            assert all(int(r["proof_bytes"]) == len(proof) for r in rows)
            hashes = {r["proof_blake3"] for r in rows}
            assert len(hashes) == 1
            result[phase] = dict(samples=len(rows), proof_bytes=len(proof),
                                 proof_blake3=hashes.pop(), metrics=metrics)
    output = []
    for (protocol, threads), result in sorted(results.items()):
        assert set(result) == {"before", "after"}
        assert result["before"]["proof_blake3"] == result["after"]["proof_blake3"]
        assert (root / "before/proofs" / f"{protocol}.proof").read_bytes() == (
            root / "after/proofs" / f"{protocol}.proof").read_bytes()
        output.append(dict(protocol=protocol, threads=int(threads), **result,
                           exact_proof_match=True, speedup={
                               key: result["before"]["metrics"][key]["median"] /
                                    result["after"]["metrics"][key]["median"]
                               for key in ("prove_ms", "verify_ms", "total_prover_ms")}))
    assert output, "no measurements found"
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    print(json.dumps(summarize(args.directory), indent=2))
