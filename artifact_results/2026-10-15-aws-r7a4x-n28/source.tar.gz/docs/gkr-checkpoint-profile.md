# GKR checkpoints at depths 3, 7, 11, 15 — 15 October 2026

The implemented checkpointed ERA prover takes **4.023 s for evaluation proving**
and **5.576 s including the initial commitment** at `2^22` input elements.
Its serialized proof is **3,007,848 bytes**. Checkpointing reduces the number of
GKR sumcheck rounds, but does **not improve total prover time** in this
implementation: evaluation proving is 18.1% slower and the proof is 3.96% larger
than the original prover measured in the same build.

These are measurements, replacing the earlier checkpoint cost estimates. The
machine is an Apple M2 with 8 CPU cores (4 performance + 4 efficiency), 16 GiB
RAM, macOS 14.0; Rust 1.92.0, release build, eight Rayon workers. They are not
measurements on a 32-core AWS machine. The field remains the secp256k1 scalar
field and the hash remains BLAKE3. The experiment uses the existing query preset;
the soundness-calibration qualifications in
[the original profile](codeswitching-profile.md#parameter-qualifications-before-a-paper-comparison)
still apply. No new equal-100-bit comparison is claimed here.

## Measured totals

Each series uses one warmup and three measured repetitions. Headline timings
are medians from runs with profiling disabled. Every measured proof was parsed
and checked by the independent verifier.

| Measurement | Original GKR | Checkpoints 3, 7, 11, 15 |
| --- | ---: | ---: |
| Initial commitment | 1,575.106 ms | 1,537.256 ms |
| Evaluation proving | 3,405.978 ms | 4,022.974 ms |
| **Initial commitment + evaluation proving** | **4,981.084 ms** | **5,576.175 ms** |
| Verification | 286.613 ms | 429.554 ms |
| Exact serialized proof | 2,893,224 bytes | 3,007,848 bytes |
| GKR sumcheck rounds | 171 | 66 |
| Additional checkpoint oracle rows | 0 | 9 |

The total is the median of each run's `commit_ms + prove_ms`, so it need not
equal the sum of the two separately reported medians. Fixed setup is excluded
from all prover totals; it took 832.792 ms and 928.562 ms in these two control
series. Input generation and output-file writes are also excluded. Evaluation
proving includes Fiat–Shamir, auxiliary and checkpoint commitments, all checks,
openings, and serialization.

Unprofiled evaluation-prover ranges were 3,306.309–6,060.746 ms for the original
and 3,999.132–4,250.942 ms with checkpoints. The original series contains a slow
first measured sample; it is retained in the raw data. Three samples on a shared
laptop are sufficient to identify these large costs, not to establish small
percentage speedups. Initial commitment follows the same code in both modes;
its timing difference is run variability.

## Protocol and authentication

Depth 0 is the root and depth 19 is the leaf layer of the padded fractional
tree. Four checkpoints split the 19 layer reductions into segments of lengths
`3, 4, 4, 4, 4`. Each checkpoint contains numerator and denominator arrays for
all four fractional trees (the two permutation checks).

All four checkpoint layers are available together after the permutation pole
challenges. They are packed, largest arrays first, into one additional Merkle
commitment containing nine BaseFold-encoded rows of message width 32,768 and
rate 1/8. There are 279,616 raw checkpoint field elements (8.533 MiB); the nine
encoded rows occupy 72 MiB of field values, excluding Merkle storage. These are
dimension-based array sizes, not measured peak process memory.

The checkpoint root is fixed before checkpoint OOD evaluations, checkpoint
evaluation points, or GKR batching challenges. Both ends of every internal
segment are authenticated: eight entry evaluations and eight exit evaluations
per checkpoint, giving 64 boundary claims. The final IP/TIP reduction includes
all of these claims plus nine checkpoint-row OOD claims. It then authenticates
the checkpoint stack as a third source in terminal BaseFold, alongside the
index and original online stacks. The leaf denominator claims and public
numerator mask are still checked. Omitting the boundary authentication would
leave a different, incomplete protocol and would give misleading timings.

The five segments advance together in four batched GKR steps. Unequal-size
sumchecks use constant extension on the unused coordinates, normalized by
`2^-(D-d)`, without allocating expanded witness tables. Their variable counts
are `15, 16, 17, 18`, hence 66 rounds. The original traversal uses
`0 + 1 + ... + 18 = 171` rounds. All segment child evaluations are sent before
the shared child-folding challenge. The root segment finishes after the third
batch; the fourth batch contains the other four segments.

The new transcript has a distinct domain/version and binds the checkpoint
schedule. Checkpointing is opt-in; omitting the CLI flag preserves the original
proof bytes and behavior.

## Profile of the new GKR

The following are **mean wall-clock times** across three separately instrumented
runs. Inclusive spans include their children; do not add a parent to its child.
The instrumented evaluation prover averaged 4,085.171 ms with checkpoints,
versus 3,571.827 ms originally.

| Disjoint work inside the GKR stage | Original | Checkpointed |
| --- | ---: | ---: |
| Fraction-tree construction | 59.040 ms | 50.349 ms |
| Layer-table preparation | 62.654 ms | 58.902 ms |
| Sumchecks, including polynomial evaluation and table folding | 862.085 ms | 845.524 ms |
| Checkpoint packing, encoding and Merkle commitment | — | 183.826 ms |
| Checkpoint OOD, boundary evaluation and authentication-claim preparation | — | 54.979 ms |
| Remaining GKR work | 4.771 ms | 3.527 ms |
| **GKR stage total** | **988.550 ms** | **1,197.107 ms** |

The checkpoint commitment's 183.826 ms comprises 148.707 ms encoding,
34.257 ms hashing, and 0.862 ms packing/framing. The sumchecks spend
**767.320 ms in polynomial evaluation** and **75.328 ms folding tables**.
Polynomial evaluation alone is 64.1% of the GKR stage and 18.8% of the entire
evaluation prover. The corresponding original polynomial-evaluation time was
778.901 ms: the arithmetic cost is effectively unchanged.

| Batched GKR step | Variables / rounds | Total step | Sumcheck portion |
| --- | ---: | ---: | ---: |
| 0 | 15 | 65.293 ms | 62.102 ms |
| 1 | 16 | 126.181 ms | 119.758 ms |
| 2 | 17 | 247.966 ms | 235.263 ms |
| 3 | 18 | 465.181 ms | 428.400 ms |
| **Total** | **66** | **904.621 ms** | **845.524 ms** |

Fewer transcript rounds do not remove the large bottom-layer tables or their
cubic arithmetic. Constant extension avoids padding costs, but the reduction
still processes every original circuit edge. The last batch alone accounts
for 51.4% of batched GKR work.

## Costs outside GKR and proof size

Checkpoint authentication also increases the final claim batch from 101 to
174 claims and the authenticated oracle stack from 68 to 77 rows. This cost is
outside the `logup_gkr` profile span and must be counted in total prover time.

| Final claim-reduction stage | Original | Checkpointed |
| --- | ---: | ---: |
| Batched IP/TIP sumcheck | 596.544 ms | 816.357 ms |
| Public-weight endpoint checks | 157.479 ms | 331.583 ms |
| Terminal BaseFold, including openings | 155.613 ms | 168.208 ms |
| Entire final claim reduction, including preparation/folding | 986.484 ms | 1,376.253 ms |

The full permutation-check stage, including GKR and its surrounding linear
claims, costs 1,428.372 ms. Other large checkpointed-prover costs are StartingIOR
(467.141 ms), the original online commitment (432.159 ms), and public evaluation
(198.554 ms).

The final generic sumcheck and endpoint checks together add about 394 ms.
Two concrete follow-up optimizations are to combine linear claims sharing an
oracle into one weighted public vector, and to reuse the common equality
weights across endpoint evaluations. A specialized cubic GKR evaluator could
reuse interpolated factors instead of recomputing them for every term and each
of the four polynomial samples. These optimizations have **not** been included
in these measurements.

| Serialized component | Original | Checkpointed |
| --- | ---: | ---: |
| Opened field elements, all oracles | 2,360,064 | 2,444,096 |
| Authentication hashes, all oracles | 357,984 | 400,384 |
| Terminal 4,096-scalar message | 131,072 | 131,072 |
| Other roots, scalars, messages and framing | 44,104 | 32,296 |
| **Total bytes** | **2,893,224** | **3,007,848** |

The checkpoint source alone adds 84,096 field bytes and 41,920 authentication
bytes. The GKR-stage transcript shrinks from 31,872 to 19,776 bytes (the latter
includes the checkpoint root and OOD values). Different transcript challenges
also change query overlap and shared Merkle authentication paths. Consequently
the exact overall increase is **114,624 bytes**, not simply the checkpoint
openings minus GKR scalar savings.

## Reproduce and inspect

From the repository root:

```sh
THREADS=8 SAMPLES=3 WARMUPS=1 \
  bash scripts/reproduce_gkr_checkpoints.sh results/gkr-checkpoints
```

This runs both original and checkpointed ERA provers, with and without profiling,
preserves the source/environment/calibration, verifies every proof, saves actual
proof bytes, checks profile accounting and proof identity, and writes checksums.
It refuses to overwrite an existing directory. For the later AWS run, set
`THREADS=32` and record the instance/CPU model; no AWS run was performed here.

To run just the new full-size prover after a release build:

```sh
cargo build --release --locked --bin compare_iopps
target/release/compare_iopps --protocol era --threads 8 \
  --samples 3 --warmups 1 --gkr-checkpoints 3,7,11,15 \
  --profile-out /tmp/gkr-checkpoint-stages.csv
```

Use `--smoke --gkr-checkpoints 3,7` for the smaller functional configuration;
its circuit does not have depths 11 or 15. Omit `--profile-out` to disable
instrumentation. Output files supplied to `--profile-out` must not already
exist. CSV output identifies the protocol variant, checkpoint depths and row
count explicitly.

The complete measured bundle is
[`artifact_results/2026-10-15-gkr-checkpoints/`](../artifact_results/2026-10-15-gkr-checkpoints/),
including [machine-readable summary](../artifact_results/2026-10-15-gkr-checkpoints/summary.json),
raw CSVs and proofs. The original proof retains BLAKE3 digest
`54d09717458e14b7085e99397c2f6308127507f3cf7ee93b4749cc7b70639fd0`;
the new proof has digest
`48580dff547d5223507f4213db65485d6480cc6b222b9dbdd3d385472f144772`.

Validation includes all 194 library tests, independent authentication of both
checkpoint boundaries and leaves, corruption rejection, non-power-of-two
padding, invalid schedule rejection, a reference comparison against explicitly
expanded sumchecks, and byte-identical proofs with profiling enabled/disabled
and one/eight worker smoke tests. Serial proof/IOPP tests also pass. Clippy
completes with warnings; logs are preserved. These checks validate the
implementation and its algebraic reductions, not the outstanding composed
security calibration. The interleaved README and paper are unchanged.
