# Why GKR checkpointing is slower — 15 October 2026

Checkpointing reduces transcript rounds but leaves essentially all the dense
GKR arithmetic in place. At depths **3, 7, 11, 15**, the extra commitment and
authentication work outweigh the transcript savings. In the fresh repeat,
GKR sumchecks take **386.1 ms without checkpoints versus 391.7 ms with them**;
including checkpoint preparation, the GKR stage takes **480.4 versus 681.8 ms**.
The final claim reduction adds another **40.5 ms** of checkpoint-related work.

This comparison uses the current optimized implementations. It does not change
either protocol or its runtime code. The benchmark still uses `2^22` inputs,
the secp256k1 scalar field, BLAKE3, the existing ERA/query preset, and eight Rayon
workers on the local Apple M2 (4 performance + 4 efficiency cores, 16 GiB RAM).
These are local measurements, not results from a 32-core AWS machine.

## Fresh side-by-side profile

Times below are **mean instrumented wall-clock milliseconds over eight measured
runs per variant** in the repeat series. Four blocks each run both variants,
alternating their order as AB, BA, AB, BA; each invocation has one warmup and
two measured samples. Setup, initial input commitment, independent verification,
and writing profile/proof files are outside the evaluation-prover timing.

The component rows above the GKR total are disjoint. Other rows explicitly
identify larger totals; do not sum those totals with their components.

| GKR component | No checkpoints | Checkpoints 3, 7, 11, 15 |
| --- | ---: | ---: |
| Construct fraction trees | 54.313 | 53.042 |
| Prepare layer tables | 35.691 | 39.379 |
| Sumcheck polynomial evaluation | 294.569 | 305.742 |
| Sumcheck table folding | 87.271 | 82.968 |
| Other sumcheck work | 4.213 | 2.988 |
| Pack, encode, and hash checkpoints | 0 | 173.598 |
| Checkpoint OOD and boundary-claim preparation | 0 | 21.614 |
| Other GKR work | 4.382 | 2.497 |
| **GKR total** | **480.439** | **681.827** |
| Final claim reduction, outside GKR | 274.098 | 314.622 |
| All remaining evaluation-prover work | 977.252 | 951.273 |
| **Whole evaluation prover** | **1,731.789** | **1,947.721** |

The GKR increase is **201.387 ms**. Checkpoint commitment and boundary
preparation account for **195.211 ms**, or approximately **97%**, of that
increase. The shared sumcheck work differs by only 5.644 ms (1.5%); its timing
ranges overlap, so this is not evidence of a substantial intrinsic arithmetic
penalty. The earlier optimized profiles also showed no sumcheck speedup
(355.3 versus 379.8 ms), although their smaller difference varied with the run.

Within the new checkpoint commitment, encoding costs **139.005 ms**, Merkle
hashing **33.567 ms**, and packing **1.023 ms**. The 21.614 ms preparation consists
of 5.830 ms of checkpoint OOD evaluations, 4.871 ms of top-boundary evaluations,
and 10.912 ms constructing authentication claims for both ends of the segments.

The separate final claim reduction grows by **40.524 ms**, including 18.599 ms
more table preparation and 14.834 ms more batched-sumcheck work. Endpoint checks
and terminal BaseFold are similar between variants. This stage must be included
when assessing checkpointing: returning boundary claims from GKR does not by
itself authenticate those claims against the committed arrays.

The evaluation prover is **215.932 ms / 12.5% slower** in this repeat. Its other
work differs by -25.979 ms, which offsets some of the measured checkpoint cost;
that difference should not be interpreted as a checkpoint optimization.

## Why fewer rounds do not save the main computation

The original prover already batches all four fraction trees. It visits circuit
depths 0 through 18 and performs `0 + 1 + ... + 18 = 171` sumcheck rounds.
Checkpointing creates five segments and advances each unfinished segment by one
layer per batch. The largest dimensions of the four batches are 15, 16, 17, 18,
so there are **66 transcript rounds**. Every original circuit layer still appears
exactly once:

| Batch | Original depths processed together | Original sumcheck time summed over those depths | Checkpointed sumcheck time |
| --- | --- | ---: | ---: |
| 0 | 0, 3, 7, 11, 15 | 33.355 ms | 33.768 ms |
| 1 | 1, 4, 8, 12, 16 | 58.896 ms | 59.854 ms |
| 2 | 2, 5, 9, 13, 17 | 103.016 ms | 103.179 ms |
| 3 | 6, 10, 14, 18 | 190.786 ms | 194.895 ms |
| **Total** | **All 19 depths** | **386.053 ms** | **391.697 ms** |

A depth-`d` table contributes `2^d - 1` pair positions across its folds. Both
variants process **524,268 positions per table role** over the circuit; the
deepest four layers account for **93.75%** of those positions. The ragged batching
implementation avoids allocating padded tables, but still evaluates and folds
each group's actual tables. It also performs a small amount of extra work for
constant groups and normalization.

In `ragged_sumcheck`, groups are processed sequentially within each round;
the existing polynomial and folding kernels parallelize their table work.
Batching combines the messages, not the arithmetic into one smaller table.
The largest group dominates each batch, so independently scheduling all five
segments would not produce five equally sized CPU jobs. The profiles do not
isolate cache, allocation, or scheduler effects, and no such explanation is
needed to account for the main slowdown.

The checkpoint payload contains `8 * (2^3 + 2^7 + 2^11 + 2^15) = 279,616`
field elements. Packing them into nine rows and encoding at rate 1/8 produces
**72 MiB of encoded field data** to hash. This is prover working data, not
the serialized proof size. There are also **64 boundary evaluation claims**
(both sides of four cuts, with eight numerator/denominator values each) and
**nine OOD claims** to authenticate.

Relevant implementation locations:

- [`fractional::prove_or_verify`](../src/proof/fractional.rs): original layer loop.
- [`checkpointed::prove_or_verify`](../src/proof/fractional/checkpointed.rs): segment batches and boundary claims.
- [`ragged_sumcheck`](../src/proof/sumcheck.rs): per-group evaluation and folding.
- [`era_iopp.rs`](../src/era_iopp.rs): checkpoint commitment and final authentication.

## Proof size

| Serialized component | No checkpoints | Checkpoints |
| --- | ---: | ---: |
| Cubic GKR sumcheck messages | 21,888 B | 8,448 B |
| GKR stage including its other scalar messages and checkpoint root | 31,872 B | 19,776 B |
| **Entire proof** | **2,893,224 B** | **3,007,848 B** |

The sumcheck messages save 13,440 bytes. The full proof nevertheless grows by
**114,624 bytes (3.96%)**, primarily because the new checkpoint oracle needs
authenticated openings. Its source opening alone occupies 126,016 bytes;
the changed transcript also changes query collisions and multiproof sizes
slightly. Fewer GKR rounds are therefore not a full-proof size improvement at
this parameter point.

## Variability and validation

Both fresh series are retained without dropping individual samples. The first
became highly variable midway through; even the common initial commitment
ranged from about 1.5 to 3.7 seconds. A complete second series was run, and the
more consistent repeat is used for the detailed comparison above. The cause of
the host variability was not established. Means and full ranges are available
in the saved JSON, rather than treating these laptop measurements as precise
hardware-isolated performance estimates.

| Series | Samples per variant | No-checkpoint prover mean (range) | Checkpoint prover mean (range) |
| --- | ---: | ---: | ---: |
| First fresh series | 8 | 2,258.629 ms (1,781.446–3,487.504) | 2,384.171 ms (1,950.463–3,622.715) |
| Complete repeat | 8 | 1,731.789 ms (1,638.936–1,918.664) | 1,947.721 ms (1,868.714–2,058.802) |

All **32 measured proofs** were independently verified. The four saved proof
files (both variants in both series) compare byte-for-byte equal to their
respective pre-optimization references; all per-run proof hashes agree.
The analysis checks complete time/byte accounting and checks each original
layer's round count before mapping it into a checkpoint batch. No GKR runtime
code changed in this profiling work.

For the current local runtime objective, the measurements favor keeping the
**uncheckpointed implementation**. The current checkpoint construction reduces
rounds but needs a cheaper commitment/authentication method, or another source
of arithmetic savings, before it becomes a prover-speed improvement.

## Reproduce

From the repository root, using a fresh output directory:

```sh
THREADS=8 BLOCKS=4 SAMPLES=2 WARMUPS=1 \
  bash scripts/profile_gkr_comparison.sh results/gkr-comparison
```

The script builds with the lockfile, records the environment and source snapshot,
alternates run order, verifies proofs, saves timings and first proofs, validates
the profiles, and produces a comparison and checksums. On the intended AWS
machine use `THREADS=32` and record its instance/CPU details.

To regenerate the analysis of the recorded repeat:

```sh
python3 scripts/summarize_gkr_comparison.py \
  artifact_results/2026-10-15-gkr-comparison/repeat
```

Raw data and source snapshots:
[`artifact_results/2026-10-15-gkr-comparison/`](../artifact_results/2026-10-15-gkr-comparison/).
The detailed table uses
[`repeat/comparison.json`](../artifact_results/2026-10-15-gkr-comparison/repeat/comparison.json).
