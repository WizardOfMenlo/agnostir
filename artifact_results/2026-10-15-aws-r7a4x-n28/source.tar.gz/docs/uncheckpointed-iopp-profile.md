# Current uncheckpointed ERA IOPP profile

The main comparison uses optimized ERA **without GKR checkpoints**, alongside
the local recursive BaseFold baseline. `Setup::new` and `compare_iopps` already
use this path by default; `scripts/reproduce_iopp_optimized.sh` now also omits
checkpointed ERA unless `INCLUDE_CHECKPOINTS=1` is explicitly supplied. The
arithmetic, encoding, and claim-batching optimizations remain enabled.

## Whole-prover measurements

These are means over the eight uncheckpointed runs in the latest complete
[paired-profile repeat](../artifact_results/2026-10-15-gkr-comparison/repeat/).
The configuration is `2^22` input elements, the secp256k1 scalar field, BLAKE3,
eight Rayon workers, seed 2025, and the existing ERA/query preset. Hardware:
Apple M2 with four performance and four efficiency cores, 16 GiB RAM. Each of
four invocations has one warmup followed by two measured samples.

| Measurement | Mean |
| --- | ---: |
| Initial input commitment | 1,501.295 ms |
| Evaluation proving, including auxiliary commitments and serialization | 1,731.791 ms |
| **Initial commitment + evaluation proving** | **3,233.087 ms** |
| Independent verification | 113.458 ms |
| Exact serialized proof size | **2,893,224 bytes** |
| Fixed setup, excluded from prover total | 838.057 ms |

The profile-root timing is 1,731.789 ms; the surrounding benchmark timer differs
by approximately 0.002 ms. Proof/profile-file writes are outside the timers.
The latest evaluation-prover range is 1,638.939–1,918.666 ms. These are
instrumented laptop measurements, not AWS scaling results. The earlier
uninstrumented median was 1,688.923 ms; the two series should not be mixed when
adding stage timings.

## Evaluation-prover breakdown

The rows below are disjoint and sum to the profile-root total. Percentages use
evaluation proving alone as the denominator, excluding the initial commitment.

| Stage | Mean | Share |
| --- | ---: | ---: |
| GKR, including fraction-tree and layer-table preparation | 480.439 ms | 27.7% |
| Online auxiliary commitment | 427.126 ms | 24.7% |
| Final claim reduction and terminal BaseFold | 274.098 ms | 15.8% |
| Permutation terminal linear-claim preparation | 141.441 ms | 8.2% |
| StartingIOR sumcheck | 133.177 ms | 7.7% |
| Permutation denominator construction | 91.064 ms | 5.3% |
| Remaining work | 184.445 ms | 10.7% |
| **Total** | **1,731.789 ms** | **100%** |

GKR is still the largest individual evaluation-prover stage, but it no longer
dominates that prover. Initial commitment plus the online auxiliary commitment
account for **1.928 s, or 59.6% of the full commitment-plus-proving time**.

The online auxiliary commitment comprises **341.293 ms encoding**,
**83.785 ms Merkle hashing**, and 2.047 ms of other work. Within GKR,
sumchecks take 386.053 ms, fraction-tree construction 54.313 ms, layer-table
preparation 35.691 ms, and other work 4.382 ms.

Within final claim reduction, table preparation costs 37.826 ms, its batched
sumcheck 151.854 ms, endpoint checks 15.909 ms, oracle folding 18.984 ms,
terminal BaseFold 45.988 ms, and remaining work 3.538 ms.

The remaining-work row consists of public evaluation (50.141 ms), tensor
checking (29.598 ms), auxiliary-witness construction (28.380 ms), initial/OOD
claims (21.948 ms), interleaved row folding (18.082 ms), accumulator claims
(16.956 ms), ERA openings (10.788 ms), and other overhead (8.552 ms).

The profile points toward commitment/encoding work as the largest opportunity
for the full prover. Within evaluation proving, auxiliary encoding and final
claim preparation/reduction are substantial alongside GKR. The initial
commitment has only a whole-stage timer in these runs, so its internal
encoding/hash split is not inferred from the online auxiliary commitment.

## Validation and reproduction

All eight proofs in this series independently verify and have the same
serialized hash. The saved proof is byte-identical to the pre-optimization
uncheckpointed proof. Switching the comparison default does not modify the
protocol, proof format, or query parameters. Existing security qualifications
and the distinction between this local BaseFold baseline and an upstream
Plonky3 implementation remain as documented in the
[optimization report](iopp-optimization-profile.md).

Run the current two-protocol comparison with a fresh output directory:

```sh
THREADS=8 SAMPLES=3 WARMUPS=1 \
  bash scripts/reproduce_iopp_optimized.sh results/iopp-uncheckpointed \
  artifact_results/2026-10-15-iopp-optimized/before/proofs
```

The script verifies both protocols and compares their actual proof files to
the supplied references. Checkpointed ERA is only included when explicitly
requested with `INCLUDE_CHECKPOINTS=1`. For the planned AWS experiment, use
`THREADS=32` and record the instance/CPU details.

Raw profiles for the measurements above are `stages-t8-b*-original.csv` in the
[repeat bundle](../artifact_results/2026-10-15-gkr-comparison/repeat/); their
matching whole-stage timing files are `timings-t8-b*-original.csv`. The bundle's
`summary.json` preserves each block's per-stage statistics. This report pools
all eight samples with equal weight.
