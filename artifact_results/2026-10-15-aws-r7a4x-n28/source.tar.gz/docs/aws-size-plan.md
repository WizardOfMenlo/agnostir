# Proof-size-optimized AWS run plan

**Campaign update:** the user has selected **2^28 elements**, retaining the two
completed measurements and continuing with only the four missing protocols.
Use the [current continuation instructions](aws-n28-continuation.md). The 2^29
recommendation and commands below are historical capacity planning, not the
active execution target.

The provisional common input size is **2^29 field elements for each comparison**.
This is 536,870,912 elements, or 16 GiB of unencoded field data. Full-size timing,
proof-size, and peak-RSS measurements have **not** been collected yet; execution
awaits access to the user's AWS instance. The capacity recommendation is an
allocation estimate, pending a pilot on that machine.

The target r7a.8xlarge has 256 GiB RAM and 32 physical cores, with one hardware
thread per core. Run with 32 Rayon workers. See the official
[AWS memory-optimized instance specifications](https://docs.aws.amazon.com/ec2/latest/instancetypes/mo.html)
and [CPU-options table](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/cpu-options-supported-instances-values.html).
Use the secp256k1 scalar field and BLAKE3 throughout.

## Selected parameters and estimates

`eta` is the logarithm of the number of interleaved rows: there are `2^eta`
rows, each with `2^(message_log - eta)` input elements. Each protocol selects
its own eta to minimize expected serialized proof bytes. The following rows
all use `message_log = 29`.

| Comparison | Protocol | eta | Rows | Elements per row | Queries | Expected proof (MiB) | Estimated peak with 15% margin (GiB) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Common interleaved argument | ERA | 9 | 512 | 2^20 | 816 | 45.038 | 133.754 |
| Common interleaved argument | BaseFold code | 10 | 1,024 | 2^19 | 1,033 | 48.555 | 92.108 |
| Common interleaved argument | Brakedown | 9 | 512 | 2^20 | 1,974 | 63.384 | 94.129 |
| Common interleaved argument | EA | 9 | 512 | 2^20 | 1,974 | 63.384 | 112.520 |
| Codeswitching comparison | Uncheckpointed ERA | 11 | 2,048 | 2^18 | 832 | 54.922 | 146.150 |
| Codeswitching comparison | Local recursive BaseFold | 4 | 16 | 2^25 | 1,344 | 6.548 | 119.600 |

For codeswitching ERA, `output_log = 15`, output rate is 1/8,
`terminal_log = 12`, and terminal BaseFold uses 147 queries. There are no GKR
checkpoints. The local BaseFold baseline also uses `terminal_log = 12`.

At 2^30 elements, the proof-minimizing interleaved ERA configuration has an
estimated live allocation of 231.507 GiB, or 266.233 GiB after the margin.
Codeswitching ERA has an estimated live allocation of 252.472 GiB, or
290.342 GiB after the margin. This makes **2^29 the recommended largest common
power of two under the current model**. It is not an experimentally established
hard maximum. Interleaved 2^30 might fit with less spare memory; it should not
be the initial full-size target. Run protocols sequentially, not concurrently.

## Optimization and distance assumptions

The search changes eta only. It preserves the current encoder parameters and
the codeswitching output/termination parameters. It considers power-of-two row
lengths supported by these configurations, requiring an even row logarithm for
the tensor-based codeswitching construction. Interleaved candidates whose
folded-message payload alone exceeds the current best proof are safely skipped.
The selected minimum is over candidates admitted by the numerical distance
checks, not all possible encoder parameters or distance bounds.

Distances are recomputed at each row length and rounded down to six decimals.
BaseFold uses a **total 102-bit setup budget**, allocated across its levels.
Brakedown uses the recursive finite-size calculation based on Haböck's analysis.
The interleaved ERA base code is checked at distance 0.0009 before applying the
ERA calculation. EA retains the user-accepted conjectured distance 0.1.

The codeswitching tensor code uses the exact Reed–Solomon distance when its
inner code stops at the RS base case. Otherwise the planner tries the descending
inner-distance grid 0.01, 0.009, ..., 0.001, accepting the first passing recursive
bound. This grid does not establish the best possible distance. Some larger
row lengths, including row logs 20 and 22, fail these checks and are excluded.
The selected row-log-18 inner code is an RS [563, 512, 52] code. Its tensor
distance feeds the ERA calculation.

The selected distances are:

| Protocol | Assumed/calculated relative distance |
| --- | ---: |
| Interleaved ERA | 0.225055 |
| Interleaved BaseFold | 0.182429 |
| Interleaved Brakedown and EA | 0.100000 |
| Codeswitching ERA | 0.228952 |
| Codeswitching terminal BaseFold | 0.772359 |
| Local recursive BaseFold | 0.148726 |

Query counts preserve the existing conventions: 100 bits in the common
interleaved argument and 104 bits in the codeswitching comparison, through
`ceil(-3 * bits / log2(1 - distance))`. These are conditional query models,
not a complete Fiat–Shamir/composed-soundness certificate. Existing qualifications
in the [distance audit](distance-audit.md) and
[IOPP optimization report](iopp-optimization-profile.md) still apply. The
recursive BaseFold baseline is the current local implementation, not the
requested optimized upstream Plonky3 implementation.

## What the estimators count

The proof model counts the current serialized field elements, roots, headers,
and openings. It computes expected distinct query counts for sampling with
replacement, and expected Merkle multiproof hashes including padded tails and
BaseFold's adjacent-pair queries. Actual Fiat–Shamir query collisions change the
exact byte count; the table reports expectations. The benchmark records the
actual verified serialized proof length.

The memory model counts 32-byte field elements, encoder/setup tables, input and
encoded rows, Merkle trees, StartingIOR's message copy and equality table, and
scratch for up to 32 active encoders. The codeswitching model also includes
preprocessed/online commitments, fraction-tree/GKR tables and dense claim
reduction weights. EA's large sparse matrix is included. A multiplicative 15%
margin is added to the estimated peak live allocation. This is an estimate,
not a rigorous bound on allocator RSS; validate it on the target before the
largest run. The runner checks predicted memory and Linux `MemAvailable`, but
does not impose an operating-system memory limit.

## Local validation

Twelve 2^22-input proofs independently verified on the 16 GiB M2 host with 32
Rayon workers: six proof-minimizing local configurations and six deliberately
different row sizes. The latter exercise the new parameter paths, including
interleaved ERA at row log 20 and codeswitching ERA at row log 18. Expected
proof sizes differ from actual sizes by **at most 0.341%** across these runs.
The memory predictions with margin exceed observed peak RSS in all twelve.
These runs validate formulas and parameter paths; they do not measure AWS
performance or establish large-input RSS.

The Rust library suite passed **198 tests**. Two exhaustive Python tests compare
the expected multiproof model against all short query tuples, including padded
trees and pair openings. All four stage-profile files satisfy exact byte
accounting and their exclusive times sum to their root time within rounding.

Both default ERA and default BaseFold proof files remain **byte-for-byte
identical** to the pre-optimization references. Custom configurations intentionally
change dimensions/query parameters and therefore produce different proofs.
In particular, the custom plan's terminal BaseFold count is 147 after allocating
the total setup budget, while the historical default remains 146.

Compact evidence, the full candidate search, rejection reasons, raw local
timings/profiles, memory measurements, commands, proof hashes, and default
identity checks are in the
[AWS size-plan bundle](../artifact_results/2026-10-15-aws-size-plan/).
Local proof payloads remain in ignored `results/large-plan-local-*` directories
to avoid adding large duplicate binaries to the repository.

## Reproduction on the r7a.8xlarge

Use the current working-tree source, including uncommitted files, and a Rust
toolchain compatible with the crate's minimum version. Build on the AWS CPU.
From the repository root:

```sh
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements-analysis.txt
export RUSTFLAGS='-C target-cpu=native'
cargo build --release --locked --bin interleaved_iopp --bin compare_iopps
cargo test --locked --lib
python3 -B -m unittest discover -s scripts -p test_large_iopp_plan.py -v
```

The saved plan is sufficient to run. To regenerate it (the finite-size search
can take several minutes):

```sh
mkdir -p results
python3 -B scripts/plan_large_iopp.py --threads 32 --ram-gib 256 \
  > results/large-iopp-plan.json 2> results/large-iopp-plan.log
```

Start with a pilot using the saved plan and a **fresh** result directory:

```sh
python3 -B scripts/run_large_iopp_plan.py \
  artifact_results/2026-10-15-aws-size-plan/plan.json results/aws-pilot-n28 \
  --logs 28 --threads 32 --samples 1 --warmups 0 \
  --memory-budget-gib 224 --instance-type r7a.8xlarge
```

Inspect each protocol's `memory.json` and its verified proof result. If the
observed RSS is consistent with the plan and there is adequate free memory,
run the full comparison:

```sh
python3 -B scripts/run_large_iopp_plan.py \
  artifact_results/2026-10-15-aws-size-plan/plan.json results/aws-full-n29 \
  --logs 29 --threads 32 --samples 1 --warmups 1 \
  --memory-budget-gib 224 --instance-type r7a.8xlarge
```

For an optional separate codeswitching profile series (not part of the
requested single-sample main run), use:

```sh
python3 -B scripts/run_large_iopp_plan.py \
  artifact_results/2026-10-15-aws-size-plan/plan.json results/aws-profile-n29 \
  --logs 29 --experiment codeswitching --threads 32 --samples 1 --warmups 1 \
  --memory-budget-gib 224 --instance-type r7a.8xlarge --profile
```

Each invocation runs its protocols sequentially and saves the source snapshot,
plan, environment, exact commands, timing CSVs, logs, proof files, per-process
peak RSS, estimate errors, and SHA-256 checksums. Each proof is independently
verified. Setup is reported separately; total prover time is `commit_ms +
prove_ms`. File writes are outside those timers. The new `--distance` and
`--custom-parameters` paths require explicit external parameters, so changing
dimensions cannot silently reuse the old preset query counts.
