# Historical Spot continuation plan: 2^28 elements

**Superseded:** the user subsequently requested a fresh six-protocol run on an
on-demand r7a.4xlarge (16 workers, 128 GiB), with one warmup and one sample for
every protocol. See [the current campaign](aws-r7a4x-n28.md). The measurements
and instructions below describe the historical Spot attempt only.

The user reduced the comparison target to **2^28 input elements** after the
second Spot instance terminated. Retain the completed interleaved ERA and
BaseFold measurements, and run only the four missing protocols. Do not run
2^29 as part of this campaign. Execution awaits a replacement instance.

## Retained measurements

These are verified single-sample pilot measurements from the r7a.8xlarge:
32 physical AMD EPYC 9R14 cores, 32 Rayon workers, Rust 1.92.0, release build
with `RUSTFLAGS='-C target-cpu=native'`, secp256k1 scalars and BLAKE3.

| Common interleaved argument | eta | Commit (s) | Evaluation prove (s) | Total prover (s) | Verify (s) | Exact proof bytes | Peak RSS (GiB) | Warmups |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| ERA | 8 | 15.841 | 15.437 | **31.278** | 1.005 | 40,541,384 | 58.858 | 0 |
| BaseFold code | 9 | 7.867 | 15.437 | **23.304** | 0.221 | 33,989,320 | 40.152 | 0 |

Setup and input generation are excluded from prover time. Peak RSS covers the
whole process. Both proofs verified during their runs. The raw timing CSVs,
memory records, parameters, commands, compiler/CPU metadata and measured-source
snapshot are retained in
[the compact evidence bundle](../artifact_results/2026-10-15-aws-n28-retained/).
Checksums were checked against the previously saved partial evidence.

The pilot proof files were not downloaded before termination. Their exact
serialized sizes and successful verification are recorded, but the binary
payloads are unavailable. Do not claim that the payloads were retained or
locally reverified. These two measurements had **zero warmups**, and retain that
metadata. The user requested keeping them rather than repeating them. Remaining
protocols retain the earlier instruction of one warmup and one measured sample;
the final table must disclose that difference.

## Remaining runs

Use the existing proof-size-optimized parameters for `message_log = 28`:

| Protocol | eta | Rows | Input elements per row |
| --- | ---: | ---: | ---: |
| Interleaved Brakedown | 9 | 512 | 2^19 |
| Interleaved EA | 9 | 512 | 2^19 |
| Uncheckpointed codeswitching ERA | 10 | 1,024 | 2^18 |
| Local recursive BaseFold IOPP | 4 | 16 | 2^24 |

The interrupted Brakedown run has no completed measurement and must be run
again. Codeswitching uses no GKR checkpoints. The BaseFold IOPP remains the
local recursive implementation; no upstream implementation change is implied.
The distance, soundness and EA conjecture qualifications in
[the size-planning report](aws-size-plan.md) still apply.

After building the two release binaries on the replacement AWS CPU, execute:

```sh
export RUSTFLAGS='-C target-cpu=native'
cargo build --release --locked --bin interleaved_iopp --bin compare_iopps
bash scripts/continue_aws_n28.sh results/aws-n28-remaining
```

The output directory must be fresh. This wrapper selects **only the four
missing cases**, explicitly fixes the input log to 28, and uses 32 workers,
one warmup and one sample. It does not overwrite the retained evidence. Inspect
the exact commands without allocating input data or creating files with:

```sh
bash scripts/continue_aws_n28.sh --dry-run
```

Combine the four new verified records with `retained-summary.json` from the
evidence bundle, keeping each row's original run metadata. The continuation
manifest lists both completed and remaining protocols. Continue five-minute
progress updates once the replacement instance is available, and retrieve
completed data promptly. Keep large proof payloads in ignored `results/`.
