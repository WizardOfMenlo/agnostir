# Fresh AWS comparison at 2^28 elements

The current campaign runs all six protocols from scratch on an on-demand
r7a.4xlarge: 16 physical AMD EPYC 9R14 cores, 128 GiB advertised RAM (about
123 GiB visible to Linux). Each protocol uses 16 Rayon workers, one warmup,
and one measured sample. Historical 32-worker Spot pilot rows are not included.
No 2^29 run is scheduled.

The field is the secp256k1 scalar field and the hash is BLAKE3. Interleaving
minimizes the estimated serialized proof size over the planner's allowed row
sizes, with the other encoder parameters fixed. EA retains its conjectured
0.1 distance. The codeswitching implementation uses no GKR checkpoints;
the comparison IOPP is the local recursive BaseFold implementation. The
conditional distance and soundness qualifications in [the planning report](aws-size-plan.md)
still apply.

| Protocol | eta | Rows | Input elements per row |
| --- | ---: | ---: | ---: |
| Interleaved ERA | 8 | 256 | 2^20 |
| Interleaved BaseFold code | 9 | 512 | 2^19 |
| Interleaved Brakedown | 9 | 512 | 2^19 |
| Interleaved EA | 9 | 512 | 2^19 |
| Uncheckpointed codeswitching ERA | 10 | 1,024 | 2^18 |
| Local recursive BaseFold IOPP | 4 | 16 | 2^24 |

## Reproduction

Use Rust 1.92.0 and the locked dependencies. Generate the plan with Python
and the pinned packages in `requirements-analysis.txt` if changing machine
parameters; the checked-in plan already targets this campaign.

```sh
python3 -m pip install -r requirements-analysis.txt
python3 -B scripts/plan_large_iopp.py --logs 28 --threads 16 --ram-gib 128 > plan.json
export RUSTFLAGS='-C target-cpu=native'
cargo build --release --locked --bin interleaved_iopp --bin compare_iopps
bash scripts/run_aws_n28.sh results/aws-r7a4x-n28
```

The result directory must be fresh. `bash scripts/run_aws_n28.sh --dry-run`
prints all six commands without allocating the large input or creating results.
The wrapper uses the saved plan in `artifact_results/2026-10-15-aws-r7a4x-n28/`.
Cases run sequentially with a 112 GiB estimated-memory budget. This is a
preflight check, not an operating-system memory limit.

The campaign retains exact proof files, timing CSVs, process peak RSS,
commands, source, compiler/CPU metadata and checksums under ignored `results/`.
Prover totals are commitment plus evaluation proof generation, excluding
setup and input generation. Peak RSS covers the complete process, including
the warmup. The measured proof is verified by the benchmark harness.

Status: preparing the fresh campaign. Results will be recorded here after
all six cases complete and the evidence is retrieved and validated.
