# Transcript-preserving IOPP optimizations — 15 October 2026

The main comparison now uses **uncheckpointed ERA**. The three-variant results
below record the optimization experiment; checkpointing is retained as an
explicit opt-in for reproducing that comparison. See the
[current whole-prover profile](uncheckpointed-iopp-profile.md).

The checkpointed ERA evaluation prover improves from **3.894 s to 1.936 s**
(**2.01×**), and total initial commitment plus evaluation proving improves from
**5.379 s to 3.417 s**. The serialized proof is **exactly identical** to the
pre-optimization proof: 3,007,848 bytes, checked by comparing the complete files.

The same shared optimizations accelerate the local BaseFold evaluation prover
from **0.784 s to 0.250 s** (3.14×). ERA without checkpoints remains faster than
checkpointed ERA, at **1.689 s**. All three protocol variants retain their
original serialized proof bytes, field, code parameters, queries, transcript
domains and challenge order.

## What changed

1. **Fused sumcheck polynomial evaluation.** Both ordinary and unequal-size
   batched sumchecks compute values at 0, 2 and 3 in one tiled pass, sharing
   interpolated factors across terms. Interpolation at the small integer points
   uses additions. The value at 1 is recovered from the existing claim,
   `g(1) = claim - g(0)`. The prover still sends the same messages, and the
   verifier still checks their sum and the independently evaluated endpoint.
   Quadratic and linear instances only compute their required samples.
2. **Combined repeated claims.** After the existing random batching challenge,
   public weight tables are combined for claims sharing the same witness row
   or pair of rows. Linearity of multilinear extension preserves the entire
   batched polynomial, including evaluations outside the Boolean cube. This
   reduces the number of terms and folded weight tables without changing the
   claimed sum, degree, transmitted oracle values or subsequent challenges.
3. **Equality-weight work.** Each expansion node uses one multiplication:
   `right = parent * coordinate; left = parent - right`. Large tables are
   expanded in independent suffix blocks. Public evaluation and StartingIOR
   reuse the same table, and final endpoint checks share one equality table
   instead of rebuilding it for every claim.
4. **One virtual-codeword encoding.** Terminal BaseFold encodes the already
   combined message once, using linearity of the common code, instead of
   combining every coordinate of the committed encoded stacks. Source
   commitments and their authenticated openings are retained.
5. **Coarse encoding jobs.** Parallel BaseFold encoding uses coarse blocks at
   small butterfly levels and tiles within large butterflies. Auxiliary batches
   parallelize within rows when there are fewer rows than Rayon workers. This
   supports the nine-row checkpoint batch on a future 32-core run without
   scheduling individual small butterflies as separate nested jobs.

The changed implementation is in `src/proof/sumcheck.rs`,
`src/poly_utils/multilinear.rs`, `src/era_iopp.rs`, `src/basefold_iopp.rs`, and
`src/commit/codes/basefold.rs`. The grand-product permutation alternative and
other protocol changes were not part of this work. The endpoint optimization
reuses and combines dense weights; it does not yet introduce symbolic
representations for every public weight function.

## Benchmark setup and measurements

Apple M2, eight CPU cores (4 performance + 4 efficiency), 16 GiB RAM, macOS
14.0 arm64; Rust/Cargo 1.92.0, release build, default parallel feature, eight
Rayon workers, seed 2025, no `target-cpu` override. Inputs contain `2^22`
secp256k1 scalar-field elements; commitments and Fiat–Shamir use BLAKE3.
This is a local machine benchmark, not an AWS or 32-core scaling result.

Before changing the source, the existing binary was preserved and used for a
fresh uninstrumented baseline. Each protocol/series has one warmup followed by
three measured repetitions. The following are **uninstrumented medians**. Every
proof was independently verified; proof-file writes and comparisons were
outside timing boundaries. Fixed setup and input generation are excluded.

| Protocol | Prove before | Prove after | Speedup | Total before | Total after |
| --- | ---: | ---: | ---: | ---: | ---: |
| ERA, checkpoints 3, 7, 11, 15 | 3,894.047 ms | **1,936.400 ms** | **2.01×** | 5,379.319 ms | **3,416.949 ms** |
| ERA, no checkpoints | 3,262.271 ms | **1,688.923 ms** | **1.93×** | 4,736.519 ms | **3,159.953 ms** |
| Local recursive BaseFold | 784.149 ms | **249.904 ms** | **3.14×** | 1,337.651 ms | **800.879 ms** |

`Prove` includes public evaluation, StartingIOR, auxiliary commitments,
Fiat–Shamir, all checks, openings and serialization. `Total` is the median of
each run's initial commitment plus evaluation proving, not the sum of separate
medians. The full comparison, including ranges, is preserved in
[`comparison.json`](../artifact_results/2026-10-15-iopp-optimized/comparison.json).

| Protocol | Initial commit after | Verify before | Verify after | Exact proof bytes |
| --- | ---: | ---: | ---: | ---: |
| ERA, checkpoints | 1,482.414 ms | 424.600 ms | **143.052 ms** | **3,007,848** |
| ERA, no checkpoints | 1,471.030 ms | 264.777 ms | **112.356 ms** | **2,893,224** |
| Local BaseFold | 535.651 ms | 24.632 ms | **23.654 ms** | **2,965,224** |

Both ERA variants have essentially unchanged initial commitment work; timing
differences there are host variability. Shared optimizations were applied to
BaseFold as well as ERA. The checkpointed ERA evaluation prover is still 7.75×
slower than this BaseFold baseline, or 4.27× counting initial commitment.
Without checkpoints those ratios are 6.76× and 3.95×.

The baseline remains this repository's recursive BaseFold implementation with
interleaving and early termination, **not a modified upstream Plonky3 fork**.
The existing `834 / 146 / 949` query preset and conditional security
calibration are unchanged; see the
[original calibration qualifications](codeswitching-profile.md#parameter-qualifications-before-a-paper-comparison).
Identical proof bytes establish execution compatibility, not a new composed
soundness theorem or an equal-100-bit benchmark certification.

## New profile and remaining costs

These are mean wall-clock times from three separate instrumented runs. They
should not be added to the uninstrumented medians above. Rows in this table
are disjoint; the remaining-work row includes preparation and smaller checks.

| Checkpointed ERA stage | Mean time |
| --- | ---: |
| GKR, including checkpoint commitment and boundary preparation | 669.894 ms |
| Original online auxiliary commitment | 410.001 ms |
| Final batched claim sumcheck | 158.965 ms |
| Permutation terminal linear claims | 137.540 ms |
| StartingIOR | 126.182 ms |
| Public evaluation | 47.907 ms |
| Terminal BaseFold, including source openings | 40.275 ms |
| Final endpoint checks | 15.810 ms |
| Remaining work | 276.106 ms |
| **Total evaluation prover** | **1,882.680 ms** |

Within GKR, polynomial evaluation now costs **299.508 ms**. Final-claim
polynomial evaluation costs **97.431 ms**, and its endpoint checks cost
15.810 ms. The virtual-codeword stage costs **14.645 ms**. These eliminate
much of the previously measured generic arithmetic and repeated-weight work.

Online auxiliary encoding still costs **327.458 ms**, before 80.988 ms of
hashing. Together with checkpoint encoding, remaining GKR arithmetic, and
permutation linear-claim preparation, these are the main targets for further
work. GKR still has four batched steps and 66 sumcheck rounds in checkpointed
mode. No-checkpoint GKR costs 442.098 ms in the new profile, versus 669.894 ms
including the checkpoint work. Checkpointing still does not pay for itself at
this parameter point on this machine.

A subsequent [paired GKR profile](gkr-comparison-profile.md) matches the two
implementations by circuit depth and separates checkpoint commitment and
authentication costs from their nearly unchanged sumcheck work.

## Exact proof identity and validation

The complete proof files before and after optimization are compared with byte
equality, not only length or a digest. All three full-size comparisons pass;
the before files also match the earlier saved profiling artifacts.

| Protocol | Unchanged BLAKE3 digest |
| --- | --- |
| ERA, checkpoints | `48580dff547d5223507f4213db65485d6480cc6b222b9dbdd3d385472f144772` |
| ERA, no checkpoints | `54d09717458e14b7085e99397c2f6308127507f3cf7ee93b4749cc7b70639fd0` |
| Local BaseFold | `2100e8b205d247adca063517897d26fc25991d3b098daba91d371f425bc5fe1f` |

Validation also includes:

- **197 passing library tests** with default features and **196 passing tests**
  without default features, including existing tampering and context checks.
- A retained test-only copy of the original sumcheck evaluator. Optimized
  degree-1/2/3 sumchecks match its complete messages, challenge points and final
  evaluations at several dimensions and worker counts. Unequal-size batches
  match the original evaluator on explicitly expanded tables.
- Equality weights checked against the direct definition, including binary
  coordinates and sizes exercising parallel expansion.
- Tiled and batch encodings checked against the sequential encoder with
  1, 8 and 32 workers and multiple rates/butterfly sizes.
- **18 additional verified smoke proofs**, using seeds 7 and 99, comparing the
  old binary against the new binary with one and 32 workers. All match exactly.
  These are functional thread checks, not 32-core performance measurements.
- Profile byte accounting and proof identity across profiling on/off and all
  measured samples. Formatting and diff checks pass. Clippy completes with
  warnings; its log is retained.

## Reproduce

The full bundle contains before/after source snapshots, raw controls and stage
CSVs, proof files, comparison summaries, validation logs and checksums:
[`artifact_results/2026-10-15-iopp-optimized/`](../artifact_results/2026-10-15-iopp-optimized/).

Reproduce all three variants of this historical optimization benchmark from the
repository root, checking proofs against the saved pre-optimization proofs:

```sh
INCLUDE_CHECKPOINTS=1 THREADS=8 SAMPLES=3 WARMUPS=1 \
  bash scripts/reproduce_iopp_optimized.sh results/iopp-optimized \
  artifact_results/2026-10-15-iopp-optimized/before/proofs
```

The script refuses to overwrite the output directory, builds with the lockfile,
runs all three variants with profiling on and off, verifies all proofs, checks
actual proof-file equality, and writes the summary and checksums. Set
`THREADS=32` on the eventual 32-core machine and record the instance/CPU model.
Use a fresh directory for each run. Omit `INCLUDE_CHECKPOINTS=1` for the current
default comparison of uncheckpointed ERA and local BaseFold only.

To regenerate the recorded before/after comparison:

```sh
python3 scripts/summarize_iopp_optimization.py \
  artifact_results/2026-10-15-iopp-optimized
```

The bundle's `commands.txt` records the original baseline commands and how to
rebuild its preserved source snapshot. The paper and interleaved README were
left unchanged.
