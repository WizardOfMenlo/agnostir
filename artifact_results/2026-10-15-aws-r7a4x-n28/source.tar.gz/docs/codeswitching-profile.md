# Codeswitching IOPP profile — 15 October 2026

At `2^22` input elements, the current ERA codeswitching implementation produces
**2,893,224 proof bytes** and takes **3.361 s** to prove an evaluation, after
**1.560 s** for the initial commitment. The local recursive BaseFold baseline
produces **2,965,224 bytes**, with **0.778 s** evaluation proving and **0.572 s**
commitment. ERA's evaluation prover is about **4.32× slower**, for a **2.43%**
smaller proof. The principal costs are permutation-check sumchecks, the batched
IP/TIP sumcheck, and auxiliary BaseFold encoding.

These are profiles of the current finite-size preset. The baseline is this
repository's recursive BaseFold with interleaving and early termination; it is
**not the requested modified upstream Plonky3 implementation**. The complete
soundness budget is still conditional, as explained below. This profile changes
instrumentation, not the protocol, distances, queries, field, or hash function.
EA and the interleaved comparison are unchanged.

Raw timings, stage records, actual proof files, source snapshot, environment,
calibration, test logs and checksums are in
[`artifact_results/2026-10-15-codeswitching-profile/`](../artifact_results/2026-10-15-codeswitching-profile/).
The machine-readable [summary](../artifact_results/2026-10-15-codeswitching-profile/summary.json)
checks that exclusive byte counts sum to the emitted proof length and that
proof identities agree across samples, worker counts, and profiling on/off.

## Setup and measurement boundaries

Apple M2, 8 CPU cores (4 performance + 4 efficiency), 16 GiB RAM, macOS arm64;
Rust/Cargo 1.92.0, release profile, default parallel feature, no `target-cpu`
override. Eight Rayon workers, seed 2025. The field is the **secp256k1 scalar
field**, using canonical 32-byte little-endian scalars, and the hash is BLAKE3.

| Parameter | ERA codeswitching | Local recursive BaseFold |
| --- | ---: | ---: |
| Input elements | 4,194,304 | 4,194,304 |
| Initial interleaving height | 64 | 32 |
| Initial row message length | 65,536 | 131,072 |
| Initial encoded row length | 315,844 | 262,144 |
| Initial queries | 834 | 949 |
| Codeswitch output message length | 32,768 | — |
| Codeswitch output rate | 1/8 | — |
| Terminal BaseFold queries | 146 | Same 949-query schedule |
| Terminal unencoded message length | 4,096 | 4,096 |
| Preprocessed index rows | 43 | 0 |
| Auxiliary online rows | 25 | 0 |

The ERA tensor base uses the actual systematic `[281,256,26]` RS base case,
repetition 4, two independent permutations and two independent nonzero
multiplier vectors. Its base word has 78,961 elements. The 43 index rows contain
the generator, two permutations and two multiplier families. The 25 online rows
contain the folded message, tensor word and two permuted words. Each auxiliary
row is encoded to 262,144 elements using BaseFold.

Setup includes fixed code generation and ERA's index encoding/Merkle commitment.
Initial commitment includes encoding all original rows and retaining the Merkle
tree. Evaluation proving includes computing the public evaluation, StartingIOR,
all auxiliary commitments/checks, Fiat–Shamir, openings and serialization.
Verification parses the serialized bytes and runs the independent verifier.
Input generation, setup and initial commitment are outside evaluation-prover
measurements. Proof-file writes and profile-CSV writes are outside all timings.
Initial commitment roots, the preprocessed index root, and the evaluation point
are public inputs outside the serialized proof.

Each measurement series has one warmup and three measured repetitions. The
following headline numbers use **profiling disabled**; each entry is the median.

| Protocol | Setup once (ms) | Commit (ms) | Prove (ms) | Verify (ms) | Exact proof bytes |
| --- | ---: | ---: | ---: | ---: | ---: |
| ERA codeswitching | 876.420 | 1,560.437 | 3,361.167 | 275.384 | 2,893,224 |
| Local BaseFold | 42.979 | 572.280 | 777.798 | 24.268 | 2,965,224 |

The median of each run's `commit + prove` is 4,977.018 ms versus 1,348.624 ms
(3.69×). These need not equal the sums of the separate medians. ERA's evaluation
prover ranged from 3,328.728 to 3,447.549 ms; BaseFold ranged from 767.955 to
779.628 ms. These are local measurements, not AWS measurements.

The separate instrumented runs had prover medians of 3,579.403 ms and 832.064 ms
and ranges of 3,330.378–3,720.166 ms and 779.751–835.982 ms, respectively. Host
variability and instrumentation are both present; the difference between these
separate series is not an isolated estimate of profiler overhead. All series
verified and emitted byte-identical proofs for each protocol.

## Where the evaluation prover spends time

The following are **mean wall-clock stage times across the three instrumented
8-worker runs**, so their disjoint shares add to 100%. They are not summed CPU
time across threads. Nested spans include their children; exclusive spans
subtract children. Allocation, scheduling and waits remain in the enclosing
wall-clock stage.

| Disjoint ERA stage | Mean ms | Share |
| --- | ---: | ---: |
| Two permutation checks, including logUp-GKR | 1,330.250 | 37.5% |
| Batched IP/TIP constraint sumcheck | 516.833 | 14.6% |
| StartingIOR sumcheck, including table preparation | 502.015 | 14.2% |
| Online auxiliary encoding and commitment | 435.779 | 12.3% |
| Public evaluation computation | 209.185 | 5.9% |
| Batched-claim endpoint checks | 155.952 | 4.4% |
| Terminal BaseFold, including its openings | 154.704 | 4.4% |
| Remaining work, including initial openings and tensor checks | 238.596 | 6.7% |
| **Total** | **3,543.314** | **100%** |

The permutation checks contain 1,086.946 ms of logUp-GKR. Within that GKR,
polynomial evaluation in the layer sumchecks alone costs **840.294 ms**.
Polynomial evaluation in the final batched IP/TIP sumcheck costs another
**437.987 ms**. These two kernels consume **36.1% of the entire evaluation
prover**, before their table-folding costs. The generic evaluator in
[`src/proof/sumcheck.rs`](../src/proof/sumcheck.rs) repeatedly interpolates
factors at 0, 1, 2, 3 for each term, including factors shared by many terms.
There are 12 terms in each GKR layer and 101 IP/TIP/OOD claims in the final
batch, over 68 oracle rows and 101 public-weight rows.

The online commitment costs **349.682 ms encoding** and **83.563 ms hashing**,
plus splitting/serialization overhead. The 25 encoded rows alone occupy
200 MiB of field values. The preprocessed index retains another 344 MiB of
encoded values; index construction is setup work, outside the prover interval.
The initial ERA commitment separately materializes about 616.9 MiB of values,
versus 256 MiB for the direct BaseFold commitment. These are array sizes derived
from dimensions, not measured peak process memory.

The endpoint check in [`Claims::close`](../src/era_iopp.rs) calls
`sumcheck::evaluate` for each of the 101 public weight vectors at the **same**
point, rebuilding the same equality-weight vector on every call. This is a
concrete avoidable cost within its 155.952 ms stage. Similarly, both provers
construct the large equality-weight table once for the public evaluation and
again for StartingIOR. The common
[`MultilinearPoint::eq_weights`](../src/poly_utils/multilinear.rs) expansion is
currently sequential.

Terminal BaseFold is a smaller target: 154.704 ms total, of which 126.223 ms
forms the virtual codeword by combining all 68 encoded rows. Only about
15 ms builds folded commitments. The original ERA openings cost about 34 ms
on average (median 11.764 ms; one slower sample), far below the arithmetic
stages. Changing the hash function is not the first prover-time optimization
suggested by this profile.

For the direct BaseFold baseline, StartingIOR and public evaluation together
account for **83.2%** of its instrumented prover time. Optimizing that common
machinery should be applied to both protocols in the comparison.

## Exact proof-size breakdown

The accounting measures increments in the actual Fiat–Shamir channel's output
buffer. Merkle openings separate field-valued columns from authentication hashes.
Repeated queries and shared authentication nodes are already deduplicated.

| Serialized component | ERA bytes | Local BaseFold bytes |
| --- | ---: | ---: |
| Opened field elements, all Merkle oracles | 2,360,064 | 2,177,216 |
| Merkle authentication hashes | 357,984 | 654,176 |
| Terminal message: 4,096 scalars | 131,072 | 131,072 |
| All other messages, roots, scalars and framing | 44,104 | 2,760 |
| **Total** | **2,893,224** | **2,965,224** |

ERA's initial 834 draws have 833 distinct columns. Opening those 64-element
columns uses **1,705,984 bytes** plus **204,832 authentication bytes**: together
**66.0% of the entire proof**. The terminal BaseFold opens 292 distinct butterfly
coordinates from both its source stacks: **401,792 field bytes** for the 43-row
index and **233,600 field bytes** for the 25-row online stack. The two stacks
also require 41,792 authentication bytes each. The later folded oracles use
18,688 field bytes and 69,568 authentication bytes.

All logUp-GKR messages together occupy just **31,872 bytes (1.10%)**: 8 root
scalars, 16 child scalars per layer for 19 layers, and four sumcheck scalars for
each of `0 + 1 + ... + 18 = 171` rounds. It is a large computation cost but a
small communication cost. Optimizing those messages cannot materially change
the total proof size.

Overall, opened field elements account for **81.6%** of ERA's proof. For a
smaller proof, the relevant next step is a parameter search over interleaving,
codeswitch dimensions/rate and termination, with recalibrated queries and exact
serialized accounting. Simply reducing queries would change the security
claim. Opening only a linear combination of a Merkle-committed column does not
authenticate that combination under the existing commitment; removing its
constituent values would require a protocol/commitment change.

## Parallel scaling and next optimization targets

These comparisons use the **instrumented** runs on the same 8-core M2.

| Protocol | 1-worker commit (ms) | 8-worker commit (ms) | 1-worker prove (ms) | 8-worker prove (ms) | Prover speedup |
| --- | ---: | ---: | ---: | ---: | ---: |
| ERA | 8,021.039 | 1,532.796 | 12,680.985 | 3,579.403 | 3.54× |
| Local BaseFold | 2,950.935 | 550.408 | 2,462.069 | 832.064 | 2.96× |

Stage-mean speedups vary: online commitment is 4.87×, the batched sumcheck is
4.84×, and GKR is 4.09×. Public evaluation is only 1.32× and endpoint checks
1.34×. These are measured wall-clock speedups, not evidence of 32-core scaling.

The prioritized follow-up work is:

1. Specialize the cubic GKR and IP/TIP sumcheck kernels: reuse interpolated
   factors, handle evaluations at 0 and 1 directly, and batch table work to
   reduce repeated memory passes and small Rayon jobs. Their polynomial
   evaluation alone is a measured 1.278 s opportunity; this is an upper bound
   on removable time, not a promised speedup.
2. Reuse equality weights across public evaluation/StartingIOR and across all
   endpoint claims at the same point. Parallelize large weight expansions with
   a cutoff for small vectors. Keep independent verifier checks intact.
3. Parallelize remaining denominator and linear-claim preparation and reduce
   copying of split/oracle/weight tables. The permutation terminal linear
   claims are 167.086 ms and denominator construction 76.016 ms in this run.
4. Investigate auxiliary BaseFold encoding and memory layout, then profile
   initial commitment encoding versus hashing separately. They are larger
   opportunities than the terminal BaseFold's fold commitments.
5. Search for a better proof-size parameter point and repeat the comparison
   against the intended upstream baseline. Retain a common field, hash,
   timing boundary and reviewed error budget.

No optimization from this list was applied in this profiling change. The
profile establishes where to work next without changing the measured protocol.

## Reproduce

From the repository root, with the Rust toolchain and NumPy/SciPy used by the
existing calibration script installed:

```sh
THREAD_COUNTS='8 1' SAMPLES=3 WARMUPS=1 \
  bash scripts/reproduce_iopp_profile.sh results/codeswitch-profile
```

The script refuses to overwrite an existing destination, builds with the
lockfile in release mode, preserves source/environment/calibration, runs both
protocols, verifies every proof, saves one proof per protocol, collects profiles
and an uninstrumented control, validates the byte accounting, and writes a
summary and SHA-256 checksums. Default inputs and code sampling use seed 2025.
The checked-in run was collected with the equivalent individual commands while
adding the profiler; its exact command sequence is in the bundle's `commands.txt`.

For the later 32-core machine run, use a fresh output directory:

```sh
THREAD_COUNTS='32 1' SAMPLES=3 WARMUPS=1 \
  bash scripts/reproduce_iopp_profile.sh results/aws-codeswitch-profile
```

Record the AWS instance/CPU model in addition to the automatically collected
CPU and environment metadata. No AWS instance was provisioned for this profile.
For a quick functional run:

```sh
cargo run --release --locked --bin compare_iopps -- \
  --smoke --threads 8 --samples 1 --warmups 0 \
  --profile-out /tmp/codeswitch-smoke-stages.csv
```

The smoke parameters have no security calibration. For a single protocol,
pass `--protocol era` or `--protocol basefold-local`. To disable instrumentation,
omit `--profile-out`. To regenerate the summary of an existing full bundle:

```sh
python3 scripts/summarize_iopp_profile.py \
  artifact_results/2026-10-15-codeswitching-profile
```

Validation for this change includes 190 passing full-library tests with default
features, 17 passing targeted IOPP tests without default features, serialized
proof identity with profiling on/off, exact sums of exclusive times/bytes, and
independent verification of all measured proofs. The reproduction script also
completed a separate one-sample functional check in an ignored results directory;
its timings are excluded from the tables above. Rust formatting and diff checks
pass. Clippy completes with warnings, recorded in its log. Detailed logs are in
the bundle.

## Parameter qualifications before a paper comparison

This run deliberately preserves the existing `834 / 146 / 949` query preset.
The [calibration snapshot](../artifact_results/2026-10-15-codeswitching-profile/calibration.json)
labels itself numerical with independent bound review pending. In particular,
`scripts/calibrate_custom.py` still passes 102 directly to BaseFold's
**per-level** `compute_formula`; it does not yet use the corrected
`distance_for_setup_bits` allocation over all 15/17 random levels. The previous
interleaved-distance audit corrected this distinction for that experiment,
not for this codeswitching preset. At these dimensions the per-level choice
alone permits failure bounds `15·2^-102` / `17·2^-102`, not `2^-102` total.

The independent-multiplier argument, composed error budget and setup sampling
assumptions described in [artifact-audit.md](artifact-audit.md) also remain
relevant. This document therefore reports performance of a concrete verified
execution, **not a certified equal-100-bit comparison or a new soundness proof**.
The paper and interleaved README were left unchanged by this profiling work.
