# agnostir artifact

Research implementations of linear codes and complete Fiat–Shamir evaluation
arguments over the secp256k1 scalar field, using BLAKE3-256 commitments.

**Read [the October 14 audit](docs/artifact-audit.md) before using these results.**
It found encoder and protocol defects in the historical experiment. The new
implementations execute and verify serialized proofs, but the full 100-bit
soundness claim and paper revision are not certified. The recursive BaseFold
comparison is local; the requested upstream Plonky3 baseline is still pending.
The repository's archival license has not yet been selected.

See [local measurements](docs/local-results.md) for the complete `2^22` results
and their interpretation.

The [adapted Bolt-min comparison](docs/bolt-adaptation.md) uses the same field,
hash, Fiat–Shamir argument, and serialized proof format as the other interleaved
rows. It retains Bolt-min's degree-16, compression-8 sketch and replaces the
binary-field RS syndrome code with rate-1/2 BaseFold. The original
[upstream commitment-only measurements](docs/bolt-comparison.md) are retained
separately as reference data.

Substantial code and documentation were produced with Codex assistance; see
[AI_DISCLOSURE.md](AI_DISCLOSURE.md).

## Build and test

Use Rust/Cargo **1.92.0** (edition 2024, crate minimum 1.91). Dependencies and
Plonky3 Git revisions are pinned by `Cargo.lock`; keep it and use `--locked`.
The first build requires access to crates.io and the pinned Git dependencies.
Subsequent cached builds can add `--offline`.

```sh
cargo build --locked --release --bins
cargo test --locked --lib
cargo test --locked --lib --no-default-features
cargo fmt --check
cargo clippy --locked --all-targets
```

Default features are `parallel` and `cli`. The experiment binaries require both.
The library also builds/tests without default features. The existing repository
has Clippy warnings; a successful Clippy invocation is not a warning-free claim.
No Python packages are needed for Rust experiments or CSV summaries. Recomputing
numerical distances requires Python (tested with 3.14.2) and the versions in
`requirements-analysis.txt`.

## Experiments

Small functional runs:

```sh
cargo run --locked --release --bin interleaved_iopp -- \
  --code era --message-log 14 --eta 2 --queries 32 --samples 1 --threads 8
cargo run --locked --release --bin compare_iopps -- --smoke --samples 1 --threads 8
```

The small-query and `--smoke` configurations have no security calibration.
Full `2^22` runs:

```sh
cargo run --locked --release --bin interleaved_iopp -- \
  --code era --message-log 22 --eta 6 --threads 32 --samples 5 --csv
cargo run --locked --release --bin compare_iopps -- --threads 32 --samples 5
```

`interleaved_iopp` accepts `brakedown`, `ea`, `basefold`, `era`, `bolt-min`, and
`conjectured-era`. Here `basefold` selects an **encoder inside the interleaved
argument**, not the recursive baseline. The conjectured code has no proven
inherited distance guarantee. `--proof-out PATH` saves the final serialized
proof to a new file. `--seed` controls reproducible benchmark inputs and public
setup; Fiat–Shamir challenges are derived from the transcript, not a seeded RNG.
The deterministic setup fixtures are for benchmarking; they do not certify the
random-code setup failure probabilities assumed by the distance analysis.

`compare_iopps` accepts `--protocol era`, `--protocol basefold-local`, or `both`.
Its full preset is defined only for `2^22` elements. ERA uses interleaving 64,
repetition 4, a tensor Brakedown base targeting inner inverse rate 1.1, BaseFold
output message `2^15`, inverse rate 8, and termination at `2^12`. At this size the
inner encoder is exactly systematic `[281,256,26]` RS. The local baseline uses
interleaving 32, inverse rate 2, and termination at `2^12`. See the audit for
query counts and differences from the paper. `--warmups` defaults to 1 and
`--samples` to 3; warmup rows are omitted from CSV.

The shared Criterion benchmark also measures the new serialized path:

```sh
IOPP_MESSAGE_LOG=22 IOPP_ETA=6 RAYON_NUM_THREADS=32 \
  cargo bench --locked --bench iopp_bench
```

## Timing and byte definitions

| Output | Includes |
| --- | --- |
| `setup_ms` | Code generation, preprocessing; ERA custom setup includes indexer encodings and its retained commitment tree. Timed once. |
| `commit_ms` | Initial row encoding, column hashing, and all retained Merkle levels needed for later openings. |
| `prove_ms` | Computing the evaluation, all protocol arithmetic, Fiat–Shamir, new commitments, multiproofs and canonical serialization. |
| `verify_ms` | Parsing the byte string, replaying Fiat–Shamir, authentication, and every verifier check. |
| `proof_bytes` | Exact length of the emitted proof, including version header, evaluation, all messages/roots and authentication data. |

Public initial and indexer roots (32 bytes each), setup, and evaluation point
are external to the evaluation proof. The claimed value is also transmitted
inside the proof and compared with the public claim. Query indices need no wire
bytes because they are derived. Repeated columns and shared paths are compressed
by the actual deterministic multiproof, not by an analytical model. Divide bytes
by 1024 for KiB. Setup and deterministic message/point generation are outside
commit/prove/verify. Every measured proof is verified, and rejection aborts a run.

Hashing uses the optimized [BLAKE3 implementation](https://github.com/BLAKE3-team/BLAKE3)
with 256-bit digests, separate leaf/node domains, and a separate transcript
domain. The generic collision target is 128 bits, above the paper's nominal
100-bit target; this is not a bound for the composed protocol. Rayon distributes
independent columns and tree nodes. Small inner products and folds run
sequentially to avoid scheduling work that exceeds their arithmetic cost.

## Reproduction on AWS

Run on the target machine with a Rust 1.92 toolchain and enough RAM. The local
`2^22` tests ran on a 16 GiB Apple M2 machine; this is not an AWS memory bound.
Check `lscpu` before equating vCPU counts with physical cores. `--threads 32`
means 32 Rayon workers, regardless of the instance's physical topology.

```sh
# Build on the measurement host; do not distribute a native-CPU binary.
export RUSTFLAGS='-C target-cpu=native'
RAYON_NUM_THREADS=32 SAMPLES=5 \
  bash scripts/reproduce_artifact.sh results/aws-32 full
# Smaller execution check:
RAYON_NUM_THREADS=32 bash scripts/reproduce_artifact.sh results/aws-smoke smoke
```

The output directory must be new. The script captures source (including dirty
files), metadata, build/test logs, raw CSVs and a JSON median/min/max summary.
It runs every standard interleaved encoder and both full protocols.
The adapted Bolt-min row is included in the common interleaved comparison.
`INCLUDE_BOLT_REFERENCE=1` additionally runs the earlier binary-field upstream
commitment baseline in a separate directory. Compare
scaling by repeating into different directories with worker counts 1, 8, 16 and
32. Keep seed, CPU flags, chunk length, and protocol parameters fixed. Separate
runs from other heavy workloads. `AGNOSTIR_CHUNK_LEN` controls the ERA parallel
prefix scan and defaults to 8192; row-level parallelism uses sequential inner
scans to avoid nested scheduling overhead.

An optional Docker build recipe is provided. It has not been exercised here:

```sh
docker build -t agnostir-artifact .
docker run --rm -v "$PWD/results:/results" -e RAYON_NUM_THREADS=32 \
  agnostir-artifact
```

## Source and paper mapping

| Source | Purpose / paper component |
| --- | --- |
| `src/interleaved_iopp/fs.rs` | Serialized replacement for the interleaved evaluation experiment, with StartingIOR randomization. |
| `src/era_iopp.rs` | StartingIOR + corrected one-stage Reduce + terminal BaseFold. |
| `src/basefold_iopp.rs` | Local recursive BaseFold, interleaving and early termination. |
| `src/proof/` and `src/proof.rs` | Transcript, canonical transport, real Merkle multiproofs, sumcheck and batched fractional GKR. |
| `src/commit/codes/` | Corrected Brakedown, ERA, tensor, EA and nested BaseFold encoders. |
| `src/codeswitching/` | Legacy scaffolding; not used by the new proof binaries. |
| `scripts/calibrate_custom.py` | Numerical finite-size adaptation; not a certified bound. |
| `scripts/reproduce_artifact.sh` | Capture and rerun the artifact experiments. |
| `scripts/summarize_artifact.py` | Summarize verified measured CSVs. |
| `artifact_results/2026-10-14/` | Measured local results, environment, and calibration inputs. |

The sibling paper's historical runtime table and estimated custom-size plot are
not regenerated as if these new measurements reproduced them. Changes to the
encoder, protocol, arithmetic, setup and wire format affect those claims.
Older root-level reports, `bench_logs/`, `docs/paper-consistency.md`, and the
Python estimator contain historical models; they are not current serialized
proof results. The estimator's strictly-decreasing-length search was repaired,
but its communication formulas still predate the full corrected transcript.

## Submission status

[ASIACRYPT 2026 requirements](https://asiacrypt.iacr.org/2026/artifacts.php) specify
source, reproducibility information, licensing, paper mapping and AI disclosure.
See the audit's remaining blockers. No public upload, licensing grant, submission
commit/tag, or AWS provisioning has been performed.
