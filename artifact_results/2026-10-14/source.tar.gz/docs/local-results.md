# Local measurements — 14 October 2026

These are measurements of the corrected implementations, not a reproduction of
the paper's historical tables or a certified 100-bit comparison. Read
[artifact-audit.md](artifact-audit.md) for the construction changes, parameter
assumptions, and unresolved security and implementation questions.

Host: Apple M2, 8 physical/logical cores, 16 GiB RAM, macOS arm64. Rust/Cargo
1.92.0, release profile, no `target-cpu` override, 8 Rayon workers, seed 2025.
Each entry is the median of three measured runs after one warmup. Every proof
was verified. Times are milliseconds. Setup is measured once separately.

## Complete protocols at 2^22 elements

| Protocol | Setup | Commit | Prove | Verify | Serialized proof bytes |
| --- | ---: | ---: | ---: | ---: | ---: |
| Corrected ERA IOPP | 832.298 | 1,468.742 | 3,348.946 | 306.694 | 2,893,224 |
| Local recursive BaseFold | 42.285 | 540.569 | 807.271 | 65.827 | 2,965,224 |

ERA's proof is 2.43% smaller here. Its evaluation prover is 4.15 times slower;
the sum of median commitment and evaluation-prover times is 4.818 seconds
versus 1.348 seconds. This does not demonstrate a prover-time improvement.
The local BaseFold implementation includes interleaving and early termination,
but is not the requested modified upstream Plonky3 implementation. ERA uses
the documented finite-size adaptation in the audit, including two independent
multiplier families and the exact finite RS base-code distance.

## Interleaved experiment at 2^22 elements, interleaving 64

| Encoder | Queries | Commit | Prove | Verify | Serialized proof bytes |
| --- | ---: | ---: | ---: | ---: | ---: |
| Brakedown | 1,974 | 816.419 | 688.097 | 96.614 | 6,429,096 |
| EA | 1,974 | 7,423.419 | 695.944 | 593.954 | 6,441,704 |
| BaseFold | 869 | 520.263 | 678.961 | 32.953 | 4,046,664 |
| ERA | 804 | 674.994 | 681.814 | 50.206 | 3,936,296 |

These are encoders within the same interleaved argument. The BaseFold row is
different from the recursive protocol above. Query counts use the CLI's
inherited, conditional distance tables; those tables still require validation
against the corrected encoders. Do not cite the rows as proven equal-security
performance results.

## Reproduction and measurement boundaries

```sh
RAYON_NUM_THREADS=8 SAMPLES=3 \
  bash scripts/reproduce_artifact.sh results/local-new full
```

The byte count is the actual proof vector length. Proving includes computation
of the evaluation, Fiat–Shamir, intermediate commitments, Merkle multiproofs,
and canonical serialization. Verification includes parsing and all checks.
Initial and preprocessing commitment roots and the evaluation point are public
inputs outside the proof. Setup and input generation are outside the reported
commit/prove/verify intervals. Setup includes ERA's indexer commitment.

Raw CSVs, calibration, environment, logs, source snapshots, and checksums are
under `artifact_results/2026-10-14/`. `source.tar.gz` is the source snapshot
captured by the measured run; `source-final.tar.gz` additionally includes the
final documentation and packaging updates. The Rust implementation is identical
in these two snapshots. `paper.patch` records edits to the sibling paper; it is
not a revised final paper or an archival paper PDF.

No AWS run or Docker execution is represented by these measurements.
